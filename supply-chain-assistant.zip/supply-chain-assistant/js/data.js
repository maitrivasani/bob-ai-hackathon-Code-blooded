/**
 * data.js — Mock data for the Supply Chain Disruption Assistant
 * All data is self-contained so the app works offline without any API.
 */

/* ── Vehicles / Fleet ─────────────────────────────────────── */
const VEHICLES = [
  { id: 'TRK-001', type: 'truck',   driver: 'James Okafor',       location: 'Gary, IN',             route: 'Chicago → Detroit',        status: 'on-route',    capacityKg: 12000, load: 92, utilization: 87, fuelPct: 62, cargo: 'Electronics',      eta: '14:30', delayMin: 0,   assignedShipment: 'SHP-2841' },
  { id: 'TRK-002', type: 'truck',   driver: 'Maria Santos',        location: 'Corsicana, TX',        route: 'Dallas → Houston',         status: 'delayed',     capacityKg: 10000, load: 68, utilization: 74, fuelPct: 41, cargo: 'Auto Parts',        eta: '17:15', delayMin: 45,  assignedShipment: 'SHP-2842' },
  { id: 'TRK-003', type: 'truck',   driver: 'Chen Wei',            location: 'Blythe, CA',           route: 'LA → Phoenix',             status: 'on-route',    capacityKg: 11000, load: 98, utilization: 95, fuelPct: 78, cargo: 'Perishables',       eta: '11:00', delayMin: 0,   assignedShipment: 'SHP-2843' },
  { id: 'TRK-004', type: 'truck',   driver: 'Priya Nair',          location: 'Seattle, WA',          route: 'Seattle → Denver',         status: 'available',   capacityKg: 12000, load: 0,  utilization: 12, fuelPct: 99, cargo: '—',                 eta: '—',     delayMin: 0,   assignedShipment: 'SHP-2849' },
  { id: 'TRK-005', type: 'truck',   driver: 'Diego Ruiz',          location: 'Fort Lauderdale, FL',  route: 'Miami → Atlanta',          status: 'delayed',     capacityKg: 9000,  load: 55, utilization: 61, fuelPct: 33, cargo: 'Textiles',          eta: '19:45', delayMin: 120, assignedShipment: 'SHP-2844' },
  { id: 'TRK-006', type: 'truck',   driver: 'Aisha Mensah',        location: 'Hartford, CT',         route: 'New York → Boston',        status: 'on-route',    capacityKg: 8000,  load: 80, utilization: 83, fuelPct: 55, cargo: 'Pharmaceuticals',   eta: '13:50', delayMin: 0,   assignedShipment: 'SHP-2845' },
  { id: 'VAN-001', type: 'van',     driver: 'Tom Bryce',           location: 'Denver, CO',           route: 'Denver → SLC',             status: 'maintenance', capacityKg: 2000,  load: 0,  utilization: 0,  fuelPct: 70, cargo: '—',                 eta: '—',     delayMin: 0,   assignedShipment: '—' },
  { id: 'VAN-002', type: 'van',     driver: 'Fatima Al-Hassan',    location: 'Mountain View, CA',    route: 'San Jose → SF',            status: 'on-route',    capacityKg: 2200,  load: 50, utilization: 55, fuelPct: 88, cargo: 'Tech Hardware',     eta: '10:20', delayMin: 0,   assignedShipment: 'SHP-2846' },
  { id: 'DRN-001', type: 'drone',   driver: 'Auto-Pilot',          location: 'San Francisco, CA',    route: 'Warehouse A → B',          status: 'on-route',    capacityKg: 30,    load: 95, utilization: 100,fuelPct: 60, cargo: 'Express Docs',      eta: '09:55', delayMin: 0,   assignedShipment: 'SHP-2850' },
  { id: 'DRN-002', type: 'drone',   driver: 'Auto-Pilot',          location: 'Oakland, CA',          route: 'Warehouse C → D',          status: 'available',   capacityKg: 30,    load: 0,  utilization: 0,  fuelPct: 100,cargo: '—',                 eta: '—',     delayMin: 0,   assignedShipment: '—' },
  { id: 'RAIL-01', type: 'rail',    driver: 'CNX Operations',      location: 'Springfield, IL',      route: 'Chicago → St Louis',       status: 'delayed',     capacityKg: 80000, load: 85, utilization: 78, fuelPct: 45, cargo: 'Bulk Grain',        eta: '22:00', delayMin: 90,  assignedShipment: 'SHP-2847' },
  { id: 'SHP-001', type: 'ship',    driver: 'Port Logistics LLC',  location: 'Pacific Ocean (32°N)', route: 'LA Port → Seattle Port',   status: 'on-route',    capacityKg: 500000,load: 99, utilization: 99, fuelPct: 52, cargo: 'Containers',        eta: 'Tomorrow 08:00', delayMin: 0, assignedShipment: 'SHP-2848' },
];

/* ── Active Disruptions ────────────────────────────────────── */
const DISRUPTIONS = [
  {
    id: 'DIS-001', severity: 'critical', type: 'weather',
    title: 'Hurricane Idalia — Gulf Coast',
    description: 'Category 2 storm making landfall near Tampa Bay. All coastal routes suspended. 14 shipments directly affected.',
    location: 'Gulf Coast, FL', affectedVehicles: ['TRK-005'], affectedRoutes: ['Miami → Atlanta','Tampa → Jacksonville'],
    estimatedResolution: '36 hrs', impact: { shipments: 14, revenueAtRisk: 320000, delayHrs: 36 }, startedAt: '2024-08-28T06:00Z', active: true
  },
  {
    id: 'DIS-002', severity: 'high', type: 'port-congestion',
    title: 'Port of Los Angeles — Congestion Surge',
    description: 'Dockworker industrial action has reduced throughput by 60%. Container processing backlog of 4,200 TEUs.',
    location: 'Los Angeles, CA', affectedVehicles: ['SHP-001','TRK-003'], affectedRoutes: ['LA Port → Seattle Port','LA → Phoenix'],
    estimatedResolution: '72 hrs', impact: { shipments: 31, revenueAtRisk: 1200000, delayHrs: 72 }, startedAt: '2024-08-27T14:00Z', active: true
  },
  {
    id: 'DIS-003', severity: 'high', type: 'traffic',
    title: 'I-94 Bridge Closure — Chicago',
    description: 'Emergency structural inspection closes both I-94 lanes near Milwaukee Ave. Detour adds 55 min to Chicago routes.',
    location: 'Chicago, IL', affectedVehicles: ['TRK-001','RAIL-01'], affectedRoutes: ['Chicago → Detroit','Chicago → St Louis'],
    estimatedResolution: '18 hrs', impact: { shipments: 8, revenueAtRisk: 85000, delayHrs: 18 }, startedAt: '2024-08-28T09:30Z', active: true
  },
  {
    id: 'DIS-004', severity: 'medium', type: 'weather',
    title: 'Severe Winter Storm — Dallas Corridor',
    description: 'Ice accumulation on TX-35 and US-77 forcing speed reductions. Fuel consumption up 18%. ETA impacts expected.',
    location: 'South Texas', affectedVehicles: ['TRK-002'], affectedRoutes: ['Dallas → Houston'],
    estimatedResolution: '5 days', impact: { shipments: 5, revenueAtRisk: 22000, delayHrs: 0 }, startedAt: '2024-08-26T00:00Z', active: true
  },
  {
    id: 'DIS-005', severity: 'medium', type: 'warehouse',
    title: 'Tier-1 Supplier Halt — Auto Parts',
    description: 'Bosch Manufacturing Austin halts production for 48 hrs due to component shortage. 3 inbound shipments paused.',
    location: 'Austin, TX', affectedVehicles: ['TRK-002'], affectedRoutes: ['Dallas → Houston'],
    estimatedResolution: '48 hrs', impact: { shipments: 3, revenueAtRisk: 65000, delayHrs: 48 }, startedAt: '2024-08-27T08:00Z', active: true
  },
  {
    id: 'DIS-006', severity: 'low', type: 'breakdown',
    title: 'VAN-001 Unscheduled Breakdown',
    description: 'Brake system fault detected. Vehicle pulled from rotation. Rescheduled load transferred to TRK-004.',
    location: 'Denver, CO', affectedVehicles: ['VAN-001'], affectedRoutes: ['Denver → SLC'],
    estimatedResolution: '6 hrs', impact: { shipments: 1, revenueAtRisk: 4000, delayHrs: 6 }, startedAt: '2024-08-28T07:15Z', active: true
  },
];

/* ── Shipments ────────────────────────────────────────────── */
const SHIPMENTS = [
  { id: 'SHP-2841', origin: 'Chicago, IL',     dest: 'Detroit, MI',          vehicle: 'TRK-001', cargo: 'Electronics',       priority: 'high',     status: 'on-time',  risk: 'low',      eta: '14:30',          value: 48000,  weightKg: 3200  },
  { id: 'SHP-2842', origin: 'Dallas, TX',      dest: 'Houston, TX',           vehicle: 'TRK-002', cargo: 'Auto Parts',        priority: 'high',     status: 'delayed',  risk: 'medium',   eta: '17:15',          value: 31000,  weightKg: 5800  },
  { id: 'SHP-2843', origin: 'Los Angeles, CA', dest: 'Phoenix, AZ',           vehicle: 'TRK-003', cargo: 'Perishables',       priority: 'critical', status: 'at-risk',  risk: 'high',     eta: '11:00',          value: 12000,  weightKg: 1100  },
  { id: 'SHP-2844', origin: 'Miami, FL',       dest: 'Atlanta, GA',           vehicle: 'TRK-005', cargo: 'Textiles',          priority: 'medium',   status: 'delayed',  risk: 'high',     eta: '19:45',          value: 19500,  weightKg: 2400  },
  { id: 'SHP-2845', origin: 'New York, NY',    dest: 'Boston, MA',            vehicle: 'TRK-006', cargo: 'Pharmaceuticals',   priority: 'critical', status: 'on-time',  risk: 'low',      eta: '13:50',          value: 92000,  weightKg: 600   },
  { id: 'SHP-2846', origin: 'San Jose, CA',    dest: 'San Francisco, CA',     vehicle: 'VAN-002', cargo: 'Tech Hardware',     priority: 'medium',   status: 'on-time',  risk: 'low',      eta: '10:20',          value: 27000,  weightKg: 800   },
  { id: 'SHP-2847', origin: 'Chicago, IL',     dest: 'St Louis, MO',          vehicle: 'RAIL-01', cargo: 'Bulk Grain',        priority: 'low',      status: 'delayed',  risk: 'medium',   eta: '22:00',          value: 8200,   weightKg: 24000 },
  { id: 'SHP-2848', origin: 'LA Port, CA',     dest: 'Seattle Port, WA',      vehicle: 'SHP-001', cargo: 'Containers',        priority: 'high',     status: 'on-time',  risk: 'medium',   eta: 'Tomorrow 08:00', value: 380000, weightKg: 120000},
  { id: 'SHP-2849', origin: 'Denver, CO',      dest: 'Salt Lake City, UT',    vehicle: 'TRK-004', cargo: 'Rerouted Load',     priority: 'low',      status: 'pending',  risk: 'low',      eta: 'TBD',            value: 4000,   weightKg: 950   },
  { id: 'SHP-2850', origin: 'Warehouse A',     dest: 'Warehouse B',           vehicle: 'DRN-001', cargo: 'Express Documents', priority: 'medium',   status: 'on-time',  risk: 'low',      eta: '09:55',          value: 500,    weightKg: 2     },
  { id: 'SHP-2851', origin: 'Portland, OR',    dest: 'Sacramento, CA',        vehicle: 'TRK-004', cargo: 'Industrial Parts',  priority: 'medium',   status: 'pending',  risk: 'low',      eta: 'Tomorrow 14:00', value: 15600,  weightKg: 7200  },
  { id: 'SHP-2852', origin: 'Atlanta, GA',     dest: 'Charlotte, NC',         vehicle: 'TRK-006', cargo: 'Consumer Goods',    priority: 'low',      status: 'on-time',  risk: 'low',      eta: '16:30',          value: 9800,   weightKg: 3100  },
];

/* ── Recovery Recommendations ─────────────────────────────── */
const RECOVERY_ACTIONS = [
  {
    id: 'REC-001', priority: 1, disruptionId: 'DIS-001',
    title: 'Reroute TRK-005 via I-75 North',
    description: 'Bypass hurricane zone entirely. Adds 180 km but avoids 36-hr standstill. Expected delay reduced from 120 min to 40 min.',
    impact: { delayReductionMin: 80, costDelta: 220, confidence: 91 },
    tags: ['reroute', 'immediate']
  },
  {
    id: 'REC-002', priority: 2, disruptionId: 'DIS-002',
    title: 'Divert SHP-001 containers to Port of Long Beach',
    description: 'Port of Long Beach currently operating at 68% capacity. Diversion adds 6 hrs but avoids 72-hr LA congestion backlog.',
    impact: { delayReductionMin: 4000, costDelta: 8500, confidence: 84 },
    tags: ['divert', 'port']
  },
  {
    id: 'REC-003', priority: 3, disruptionId: 'DIS-003',
    title: 'Use I-290 alternate for Chicago departures',
    description: 'I-290 W to I-88 corridor adds 12 min but avoids the full 55-min I-94 detour. GPS updated for TRK-001 and RAIL-01 feeder.',
    impact: { delayReductionMin: 43, costDelta: 15, confidence: 97 },
    tags: ['reroute', 'low-cost']
  },
  {
    id: 'REC-004', priority: 4, disruptionId: 'DIS-005',
    title: 'Pre-position TRK-004 to Austin for supplier pickup',
    description: 'TRK-004 is currently idle in Seattle. Repositioning to Austin warehouse ensures first-available departure when Bosch resumes.',
    impact: { delayReductionMin: 120, costDelta: 1100, confidence: 76 },
    tags: ['repositioning', 'proactive']
  },
];

/* ── Historical utilization (7-day sparkline values) ─────── */
const UTIL_HISTORY = {
  'TRK-001': [72, 80, 75, 88, 90, 85, 87],
  'TRK-002': [60, 65, 70, 72, 68, 71, 74],
  'TRK-003': [88, 91, 94, 96, 95, 93, 95],
  'TRK-004': [55, 40, 20, 10, 0,  8,  12],
  'TRK-005': [80, 78, 65, 58, 55, 60, 61],
  'TRK-006': [70, 75, 80, 82, 80, 84, 83],
  'VAN-001': [60, 55, 50, 45, 40, 20, 0 ],
  'VAN-002': [40, 45, 50, 52, 55, 54, 55],
  'DRN-001': [90, 95, 100,100,98, 100,100],
  'DRN-002': [80, 60, 40, 20, 10, 0,  0 ],
  'RAIL-01': [85, 82, 80, 78, 75, 76, 78],
  'SHP-001': [95, 97, 99, 99, 99, 99, 99],
};

/* ── Disruption type icons (inline SVG paths) ─────────────── */
const DISRUPTION_TYPE_ICONS = {
  weather:          'M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z',
  'port-congestion':'M3 4h13M3 8h9m-9 4h9m5-4v12m0 0l-4-4m4 4l4-4',
  traffic:          'M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7',
  breakdown:        'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z',
  warehouse:        'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4',
  fuel:             'M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3',
};

/* ── Vehicle type icons ───────────────────────────────────── */
const VEHICLE_TYPE_ICONS = {
  truck: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="1" y="3" width="15" height="13" rx="1"/><path d="M16 8h4l3 3v5h-7V8z"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`,
  van:   `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2" y="6" width="20" height="12" rx="2"/><path d="M2 12h20M7 18v2M17 18v2"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/></svg>`,
  drone: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M12 2l-2 4h4l-2-4zM12 22l2-4H10l2 4zM2 12l4 2V10L2 12zM22 12l-4-2v4l4-2z"/></svg>`,
  rail:  `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4" y="4" width="16" height="12" rx="2"/><path d="M4 11h16M8 16l-2 4M16 16l2 4M4 8h3M10 8h3"/></svg>`,
  ship:  `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M2 20a2 2 0 004 0 2 2 0 004 0 2 2 0 004 0 2 2 0 004 0M4 16l2-8h12l2 8M10 8V4h4v4"/></svg>`,
};

/* ── India Logistics Hubs ─────────────────────────────────── */
const INDIA_HUBS = [
  { id: 'MUM', name: 'Mumbai',        lat: 19.07, lng: 72.87, type: 'port',    utilization: 91, activeShipments: 38, status: 'active',    desc: 'Major west-coast container port & financial hub' },
  { id: 'DEL', name: 'Delhi / NCR',   lat: 28.61, lng: 77.21, type: 'rail',    utilization: 78, activeShipments: 27, status: 'delayed',   desc: 'Inland container depot & national rail junction' },
  { id: 'AHM', name: 'Ahmedabad',     lat: 23.02, lng: 72.57, type: 'road',    utilization: 68, activeShipments: 14, status: 'active',    desc: 'Textile & pharmaceutical logistics corridor' },
  { id: 'CHE', name: 'Chennai',       lat: 13.08, lng: 80.27, type: 'port',    utilization: 85, activeShipments: 22, status: 'active',    desc: 'East-coast auto & container port' },
  { id: 'KOL', name: 'Kolkata',       lat: 22.57, lng: 88.36, type: 'port',    utilization: 62, activeShipments: 11, status: 'at-risk',   desc: 'Gateway to NE India & Bangladesh corridor' },
  { id: 'BLR', name: 'Bengaluru',     lat: 12.97, lng: 77.59, type: 'air',     utilization: 89, activeShipments: 19, status: 'active',    desc: 'Tech hardware & aerospace logistics hub' },
  { id: 'HYD', name: 'Hyderabad',     lat: 17.38, lng: 78.49, type: 'road',    utilization: 74, activeShipments: 16, status: 'active',    desc: 'Pharma export & IT supply chain node' },
  { id: 'MUN', name: 'Mundra',        lat: 22.84, lng: 69.72, type: 'port',    utilization: 96, activeShipments: 44, status: 'high-util', desc: "India's largest private container port" },
  { id: 'JNP', name: 'JNPT / Nhava Sheva', lat: 18.95, lng: 72.94, type: 'port', utilization: 88, activeShipments: 51, status: 'delayed', desc: 'Busiest container port in India — 55% of EXIM traffic' },
  { id: 'KAR', name: 'Karachi',       lat: 24.86, lng: 67.01, type: 'port',    utilization: 55, activeShipments: 8,  status: 'active',    desc: 'Pakistan major port — Pak-India overland corridor' },
  { id: 'COL', name: 'Colombo',       lat: 6.93,  lng: 79.85, type: 'port',    utilization: 81, activeShipments: 17, status: 'active',    desc: 'Sri Lanka transshipment hub — key India feeder port' },
  { id: 'DHK', name: 'Dhaka',         lat: 23.81, lng: 90.41, type: 'road',    utilization: 59, activeShipments: 9,  status: 'at-risk',   desc: 'Bangladesh textile export gateway' },
  { id: 'KTM', name: 'Kathmandu',     lat: 27.70, lng: 85.31, type: 'road',    utilization: 44, activeShipments: 5,  status: 'active',    desc: 'Nepal landlocked corridor via Kolkata/Raxaul' },
  { id: 'YAN', name: 'Yangon',        lat: 16.87, lng: 96.19, type: 'port',    utilization: 48, activeShipments: 6,  status: 'active',    desc: 'Myanmar port — India–Myanmar–Thailand corridor' },
  { id: 'KUN', name: "Kunming",       lat: 25.05, lng: 102.71,type: 'rail',    utilization: 70, activeShipments: 12, status: 'disrupted', desc: 'China SW logistics hub — Sino-Indian trade node' },
];

/* ── India Supply-Chain Routes ────────────────────────────── */
const INDIA_ROUTES = [
  { id: 'RT-01', from: 'MUM', to: 'DEL', mode: 'rail',  status: 'active',    label: 'Mumbai → Delhi Rail Corridor',     delay: 0,   risk: 12, util: 82, cargo: 'Consumer Goods, Electronics' },
  { id: 'RT-02', from: 'MUM', to: 'AHM', mode: 'road',  status: 'active',    label: 'Mumbai–Ahmedabad Expressway',       delay: 0,   risk: 8,  util: 71, cargo: 'Textiles, Pharma' },
  { id: 'RT-03', from: 'MUN', to: 'DEL', mode: 'road',  status: 'high-util', label: 'Mundra Port → Delhi (NH-48)',       delay: 15,  risk: 18, util: 96, cargo: 'Containers, Bulk' },
  { id: 'RT-04', from: 'JNP', to: 'MUM', mode: 'road',  status: 'delayed',   label: 'JNPT → Mumbai City (congestion)',   delay: 65,  risk: 35, util: 88, cargo: 'Import Containers' },
  { id: 'RT-05', from: 'CHE', to: 'BLR', mode: 'road',  status: 'active',    label: 'Chennai–Bengaluru Industrial',      delay: 0,   risk: 10, util: 79, cargo: 'Auto Parts, Tech Hardware' },
  { id: 'RT-06', from: 'CHE', to: 'HYD', mode: 'rail',  status: 'active',    label: 'Chennai–Hyderabad Rail',            delay: 0,   risk: 9,  util: 68, cargo: 'Pharma, Steel' },
  { id: 'RT-07', from: 'KOL', to: 'DEL', mode: 'rail',  status: 'delayed',   label: 'Kolkata–Delhi Grand Chord',         delay: 90,  risk: 42, util: 74, cargo: 'Coal, Fertilizers' },
  { id: 'RT-08', from: 'BLR', to: 'HYD', mode: 'road',  status: 'active',    label: 'Bengaluru–Hyderabad NH-44',         delay: 0,   risk: 7,  util: 65, cargo: 'IT Hardware, Pharma' },
  { id: 'RT-09', from: 'MUM', to: 'CHE', mode: 'sea',   status: 'active',    label: 'Mumbai–Chennai Coastal Shipping',   delay: 0,   risk: 11, util: 77, cargo: 'Bulk Cargo, Vehicles' },
  { id: 'RT-10', from: 'JNP', to: 'COL', mode: 'sea',   status: 'active',    label: 'JNPT → Colombo Feeder',             delay: 0,   risk: 14, util: 84, cargo: 'Transshipment Containers' },
  { id: 'RT-11', from: 'CHE', to: 'COL', mode: 'sea',   status: 'active',    label: 'Chennai → Colombo Short-Sea',       delay: 0,   risk: 12, util: 81, cargo: 'Containers' },
  { id: 'RT-12', from: 'KOL', to: 'DHK', mode: 'road',  status: 'at-risk',   label: 'Kolkata → Dhaka Border Trade',      delay: 40,  risk: 55, util: 58, cargo: 'Textiles, Consumer Goods' },
  { id: 'RT-13', from: 'KOL', to: 'KTM', mode: 'road',  status: 'active',    label: 'Kolkata → Kathmandu (Raxaul)',      delay: 0,   risk: 20, util: 44, cargo: 'Fuel, Essentials' },
  { id: 'RT-14', from: 'MUN', to: 'KAR', mode: 'sea',   status: 'disrupted', label: 'Mundra ↔ Karachi Corridor',         delay: 0,   risk: 88, util: 22, cargo: 'Restricted — regulatory hold' },
  { id: 'RT-15', from: 'MUM', to: 'KAR', mode: 'sea',   status: 'disrupted', label: 'Mumbai ↔ Karachi Trade Route',      delay: 0,   risk: 85, util: 18, cargo: 'Bilateral trade suspended' },
  { id: 'RT-16', from: 'KOL', to: 'YAN', mode: 'road',  status: 'at-risk',   label: 'Kolkata → Yangon (IMBCTT)',         delay: 120, risk: 61, util: 47, cargo: 'Project Cargo, Agriculture' },
  { id: 'RT-17', from: 'DEL', to: 'KUN', mode: 'road',  status: 'disrupted', label: 'Delhi → Kunming (Silk Road)',        delay: 0,   risk: 90, util: 15, cargo: 'Border tensions — suspended' },
];
