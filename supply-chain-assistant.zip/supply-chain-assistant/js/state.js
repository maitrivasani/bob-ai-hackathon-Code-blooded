/**
 * state.js — Centralised application state + minimal event bus.
 * All views read from AppState and call AppState.set() to update.
 */

const AppState = (() => {
  let _state = {
    currentView: 'dashboard',
    expandedDisruption: null,
    filters: {
      fleetStatus:     'all',   // 'all' | 'on-route' | 'delayed' | 'available' | 'maintenance'
      disruption:      'all',   // 'all' | 'critical' | 'high' | 'medium' | 'low'
      shipmentStatus:  'all',   // 'all' | 'on-time' | 'delayed' | 'at-risk' | 'pending'
      shipmentSearch:  '',
      shipmentRisk:    'all',   // 'all' | 'high' | 'medium' | 'low'
    },
    simulator: {
      disruptionType: 'breakdown',
      severity: 'high',
      durationHrs: 24,
      targetVehicle: '',
      result: null,
    },
    lastUpdated: new Date(),
  };

  const _listeners = {};

  function get(key) {
    return key ? _state[key] : { ..._state };
  }

  function set(key, value) {
    _state[key] = value;
    _emit(key, value);
    _emit('*', _state);
  }

  function on(event, fn) {
    if (!_listeners[event]) _listeners[event] = [];
    _listeners[event].push(fn);
    return () => { _listeners[event] = _listeners[event].filter(f => f !== fn); };
  }

  function _emit(event, data) {
    (_listeners[event] || []).forEach(fn => fn(data));
  }

  return { get, set, on };
})();
