/**
 * app.js — Bootstrap & Router
 * Initialises the application, handles navigation, wires sidebar,
 * starts live-update ticker, manages notifications, and provides
 * shared modal/toast helpers.
 */

/* ── View registry ────────────────────────────────────────── */
const VIEWS = {
  dashboard:   { render: renderDashboard,   title: 'Dashboard',              subtitle: 'Operations Overview' },
  fleet:       { render: renderFleet,        title: 'Fleet Utilization',      subtitle: 'Vehicles & Loads' },
  shipments:   { render: renderShipments,    title: 'Shipments',              subtitle: 'Shipment Register' },
  disruptions: { render: renderDisruptions,  title: 'Disruptions',            subtitle: 'Events & Recovery' },
  assistant:   { render: renderAssistant,    title: 'Decision Assistant',     subtitle: 'Rule-Based Prototype' },
  simulator:   { render: renderSimulator,    title: 'Scenario Simulator',     subtitle: 'What-If Analysis' },
};

/* ── Navigation ───────────────────────────────────────────── */
function navigateTo(viewId) {
  if (!VIEWS[viewId]) return;

  document.querySelectorAll('.view').forEach(el => el.classList.remove('active'));
  const target = document.getElementById('view-' + viewId);
  if (target) target.classList.add('active');

  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.view === viewId);
  });

  const titleEl = document.getElementById('topbar-title');
  const subEl   = document.getElementById('topbar-sub');
  if (titleEl) titleEl.textContent = VIEWS[viewId].title;
  if (subEl)   subEl.textContent   = VIEWS[viewId].subtitle || '';

  AppState.set('currentView', viewId);
  VIEWS[viewId].render();
}

/* ── Sidebar toggle (mobile) ──────────────────────────────── */
function toggleSidebar() {
  document.querySelector('.sidebar').classList.toggle('open');
}

/* ── Live clock ───────────────────────────────────────────── */
function startClock() {
  function tick() {
    const el = document.getElementById('live-time');
    if (el) el.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }
  tick();
  setInterval(tick, 1000);
}

/* ── Dynamic badge updates ────────────────────────────────── */
function updateBadges() {
  const disCount   = DISRUPTIONS.filter(d => d.active).length;
  const fleetDel   = VEHICLES.filter(v => v.status === 'delayed').length;
  const shipRisk   = SHIPMENTS.filter(s => s.risk === 'high').length;
  const assistRecs = analyseSupplyChain().filter(r => r.urgency === 'critical' || r.urgency === 'high').length;

  const navDis    = document.getElementById('nav-badge-dis');
  const navFleet  = document.getElementById('nav-badge-fleet');
  const navShip   = document.getElementById('nav-badge-ship');
  const navAssist = document.getElementById('nav-badge-assist');

  if (navDis)    navDis.textContent    = disCount;
  if (navFleet)  navFleet.textContent  = fleetDel;
  if (navShip)   navShip.textContent   = shipRisk;
  if (navAssist) navAssist.textContent = assistRecs || '—';

  // Topbar notification tooltip
  const notifWrap = document.querySelector('.notif-wrap');
  if (notifWrap) notifWrap.setAttribute('data-tooltip', disCount + ' active disruption' + (disCount !== 1 ? 's' : ''));
}

/* ── Simulated live-refresh ───────────────────────────────── */
function startLiveRefresh() {
  setInterval(() => {
    const current = AppState.get('currentView');
    if (VIEWS[current]) VIEWS[current].render();
    updateBadges();
  }, 60000);
}

/* ── Toast notifications ──────────────────────────────────── */
let _toastTimer = null;

function showToast(message, type = 'info', duration = 5000) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast--${type}`;
  toast.innerHTML = `
    <div class="toast__icon">
      ${type === 'critical' || type === 'danger'
        ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>'
        : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>'
      }
    </div>
    <div class="toast__body">
      <div class="toast__message">${message}</div>
    </div>
    <button class="toast__close" onclick="this.closest('.toast').remove()">×</button>
  `;
  container.appendChild(toast);

  // Auto dismiss
  setTimeout(() => {
    if (toast.parentNode) toast.classList.add('toast--out');
    setTimeout(() => { if (toast.parentNode) toast.remove(); }, 350);
  }, duration);
}

/* ── Notifications panel toggle ───────────────────────────── */
function toggleNotifications() {
  let panel = document.getElementById('notif-panel');
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'notif-panel';
    panel.className = 'notif-panel';
    panel.innerHTML = `
      <div class="notif-panel__header">
        <span class="notif-panel__title">Notifications</span>
        <button onclick="document.getElementById('notif-panel').remove()" style="background:none;border:none;cursor:pointer;color:var(--text-muted);font-size:1.1rem">&times;</button>
      </div>
      <div class="notif-panel__list">
        ${DISRUPTIONS.filter(d => d.active && (d.severity === 'critical' || d.severity === 'high')).map(d => `
          <div class="notif-item notif-item--${d.severity}" onclick="navigateTo('disruptions');document.getElementById('notif-panel').remove()">
            <div class="notif-item__dot"></div>
            <div>
              <div class="notif-item__title">${d.title}</div>
              <div class="notif-item__sub">${d.location} &bull; ${d.impact.shipments} shipments &bull; ${fmtCurrency(d.impact.revenueAtRisk)}</div>
            </div>
            <div class="notif-item__sev">${severityBadge(d.severity)}</div>
          </div>`).join('')}
        ${VEHICLES.filter(v => v.status === 'delayed' && v.delayMin >= 60).map(v => `
          <div class="notif-item notif-item--warn" onclick="navigateTo('fleet');document.getElementById('notif-panel').remove()">
            <div class="notif-item__dot"></div>
            <div>
              <div class="notif-item__title">${v.id} delayed ${fmtDelay(v.delayMin)}</div>
              <div class="notif-item__sub">${v.route} &bull; ${v.cargo}</div>
            </div>
          </div>`).join('')}
      </div>
    `;
    document.body.appendChild(panel);
    // Close on outside click
    setTimeout(() => {
      document.addEventListener('click', function _close(e) {
        if (!panel.contains(e.target) && !e.target.closest('.notif-btn')) {
          panel.remove();
          document.removeEventListener('click', _close);
        }
      });
    }, 50);
  } else {
    panel.remove();
  }
}

/* ── Modal helper ─────────────────────────────────────────── */
function showModal(bodyHtml, title = 'Detail') {
  // Remove any existing modal
  const existing = document.getElementById('app-modal');
  if (existing) existing.remove();

  const modal = document.createElement('div');
  modal.id = 'app-modal';
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal-box" onclick="event.stopPropagation()">
      <div class="modal-header">
        <div class="modal-title">${title}</div>
        <button class="modal-close" onclick="document.getElementById('app-modal').remove()">&times;</button>
      </div>
      <div class="modal-body">${bodyHtml}</div>
    </div>
  `;
  modal.addEventListener('click', () => modal.remove());
  document.body.appendChild(modal);

  // Animate in
  requestAnimationFrame(() => modal.classList.add('modal-overlay--open'));
}

/* ── Show critical disruption alerts on load ──────────────── */
function showInitialAlerts() {
  const critical = DISRUPTIONS.filter(d => d.active && d.severity === 'critical');
  if (critical.length > 0) {
    setTimeout(() => {
      showToast(
        `⚠ ${critical.length} critical disruption${critical.length > 1 ? 's' : ''} active — ${critical[0].title}`,
        'critical',
        7000
      );
    }, 800);
  }
  const highRisk = SHIPMENTS.filter(s => s.risk === 'high');
  if (highRisk.length > 0) {
    setTimeout(() => {
      showToast(
        `${highRisk.length} high-risk shipment${highRisk.length > 1 ? 's' : ''} require attention`,
        'danger',
        6000
      );
    }, 2200);
  }
}

/* ── Bootstrap ────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.nav-item[data-view]').forEach(item => {
    item.addEventListener('click', () => {
      navigateTo(item.dataset.view);
      // Close sidebar on mobile after navigation
      if (window.innerWidth <= 700) {
        document.querySelector('.sidebar').classList.remove('open');
      }
    });
  });

  // Wire notification button
  const notifBtn = document.querySelector('.notif-btn');
  if (notifBtn) notifBtn.addEventListener('click', toggleNotifications);

  navigateTo('dashboard');
  startClock();
  startLiveRefresh();
  updateBadges();
  showInitialAlerts();
});
