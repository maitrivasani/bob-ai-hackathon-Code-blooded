/**
 * fleet.js — Fleet Utilization view
 * Full table with vehicle ID, current location, capacity, load,
 * utilization, status, assigned shipment. Filter by status, sort any column.
 */

/* ── Sort state ───────────────────────────────────────────── */
const _fleetSort = { col: 'id', dir: 'asc' };

function renderFleet() {
  const view   = document.getElementById('view-fleet');
  const filter = AppState.get('filters').fleetStatus;

  const countByStatus = {
    'on-route':    VEHICLES.filter(v => v.status === 'on-route').length,
    'delayed':     VEHICLES.filter(v => v.status === 'delayed').length,
    'available':   VEHICLES.filter(v => v.status === 'available').length,
    'maintenance': VEHICLES.filter(v => v.status === 'maintenance').length,
  };
  const avgUtil = Math.round(VEHICLES.reduce((s,v) => s + v.utilization, 0) / VEHICLES.length);

  view.innerHTML = `
    <div class="page-header">
      <div class="page-header__meta">
        <div class="page-header__title">Fleet Utilization</div>
        <div class="page-header__sub">${VEHICLES.length} vehicles &bull; last updated ${new Date().toLocaleTimeString()}</div>
      </div>
      <div class="page-header__controls">
        <select class="form-select" style="width:auto" onchange="setFleetFilter(this.value)">
          <option value="all"         ${filter==='all'?'selected':''}>All Status</option>
          <option value="on-route"    ${filter==='on-route'?'selected':''}>En Route</option>
          <option value="delayed"     ${filter==='delayed'?'selected':''}>Delayed</option>
          <option value="available"   ${filter==='available'?'selected':''}>Available</option>
          <option value="maintenance" ${filter==='maintenance'?'selected':''}>Maintenance</option>
        </select>
      </div>
    </div>

    <!-- Stat strip -->
    <div class="stat-row">
      <div class="stat-row__item">
        <span class="stat-row__label">En Route</span>
        <span class="stat-row__value" style="color:var(--status-ok)">${countByStatus['on-route']}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">Delayed</span>
        <span class="stat-row__value" style="color:var(--status-danger)">${countByStatus['delayed']}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">Available</span>
        <span class="stat-row__value" style="color:var(--status-info)">${countByStatus['available']}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">Maintenance</span>
        <span class="stat-row__value" style="color:var(--status-warn)">${countByStatus['maintenance']}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">Fleet Avg Utilization</span>
        <span class="stat-row__value">${avgUtil}%</span>
      </div>
    </div>

    <!-- Fleet table -->
    <div class="card">
      <div class="card__header">
        <span class="card__title">Vehicle Registry</span>
        <span class="badge badge--neutral">${_getFilteredFleet(filter).length} vehicles shown</span>
      </div>
      <div class="data-table-wrap">
        <table class="data-table sortable-table" id="fleet-table">
          <thead>
            <tr>
              ${_fleetTh('id',         'Vehicle ID')}
              ${_fleetTh('type',       'Type')}
              ${_fleetTh('location',   'Current Location')}
              ${_fleetTh('capacityKg','Capacity')}
              ${_fleetTh('load',       'Load %')}
              ${_fleetTh('utilization','Utilization')}
              ${_fleetTh('fuelPct',    'Fuel')}
              ${_fleetTh('status',     'Status')}
              ${_fleetTh('assignedShipment','Shipment')}
              ${_fleetTh('eta',        'ETA')}
            </tr>
          </thead>
          <tbody>
            ${_getFilteredFleet(filter).map(renderFleetRow).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Vehicle card grid (secondary view) -->
    <div style="margin-top:var(--sp-5)">
      <div style="font-size:.875rem;font-weight:600;margin-bottom:var(--sp-4);color:var(--text-secondary)">Vehicle Detail Cards</div>
      <div class="vehicles-grid">
        ${_getFilteredFleet(filter).map(renderVehicleCard).join('')}
      </div>
    </div>
  `;
}

function _fleetTh(col, label) {
  const isActive = _fleetSort.col === col;
  const arrow    = isActive ? (_fleetSort.dir === 'asc' ? ' ↑' : ' ↓') : '';
  return `<th class="sortable-th${isActive ? ' sorted' : ''}" onclick="sortFleet('${col}')">${label}${arrow}</th>`;
}

function _getFilteredFleet(filter) {
  let list = filter === 'all' ? [...VEHICLES] : VEHICLES.filter(v => v.status === filter);

  list.sort((a, b) => {
    let va = a[_fleetSort.col], vb = b[_fleetSort.col];
    if (typeof va === 'string') va = va.toLowerCase();
    if (typeof vb === 'string') vb = vb.toLowerCase();
    if (va < vb) return _fleetSort.dir === 'asc' ? -1 : 1;
    if (va > vb) return _fleetSort.dir === 'asc' ? 1 : -1;
    return 0;
  });

  return list;
}

function renderFleetRow(v) {
  const statusMap = {
    'on-route':    'ok',
    'delayed':     'danger',
    'available':   'info',
    'maintenance': 'warn',
  };
  const scol      = statusMap[v.status] || 'neutral';
  const utilColor = v.utilization >= 80 ? 'var(--status-ok)' : v.utilization >= 40 ? 'var(--brand-primary)' : 'var(--status-danger)';
  const loadKg    = Math.round((v.load / 100) * v.capacityKg);
  const capStr    = v.capacityKg >= 1000 ? (v.capacityKg / 1000).toFixed(0) + ' t' : v.capacityKg + ' kg';
  const delayBadge = v.delayMin > 0 ? `<span class="badge badge--danger" style="margin-left:4px">+${fmtDelay(v.delayMin)}</span>` : '';

  return `
    <tr class="fleet-row" onclick="showVehicleDetail('${v.id}')">
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <span style="color:var(--brand-primary)">${VEHICLE_TYPE_ICONS[v.type] || ''}</span>
          <strong>${v.id}</strong>
        </div>
      </td>
      <td><span class="t-mono" style="text-transform:capitalize">${v.type}</span></td>
      <td>${v.location}</td>
      <td>${capStr}</td>
      <td>
        <div style="display:flex;align-items:center;gap:8px;min-width:90px">
          <div class="progress-bar" style="flex:1">
            <div class="progress-bar__fill" style="width:${v.load}%;background:${utilColor}"></div>
          </div>
          <span style="font-size:.8rem;font-weight:600;min-width:30px">${v.load}%</span>
        </div>
      </td>
      <td>
        <div style="display:flex;align-items:center;gap:8px;min-width:100px">
          <div class="progress-bar" style="flex:1">
            <div class="progress-bar__fill" style="width:${v.utilization}%;background:${utilColor}"></div>
          </div>
          <span style="font-size:.8rem;font-weight:600;min-width:34px">${v.utilization}%</span>
        </div>
      </td>
      <td>
        <div style="display:flex;align-items:center;gap:6px">
          <div class="progress-bar" style="width:48px">
            <div class="progress-bar__fill" style="width:${v.fuelPct}%;background:${v.fuelPct < 30 ? 'var(--status-danger)' : 'var(--status-ok)'}"></div>
          </div>
          <span style="font-size:.8rem">${v.fuelPct}%</span>
        </div>
      </td>
      <td><span class="badge badge--${scol}">${v.status}</span>${delayBadge}</td>
      <td>${v.assignedShipment !== '—' ? `<span class="t-mono link-like" onclick="event.stopPropagation();navigateTo('shipments');setTimeout(()=>highlightShipment('${v.assignedShipment}'),150)">${v.assignedShipment}</span>` : '<span class="t-muted">—</span>'}</td>
      <td>${v.eta}</td>
    </tr>`;
}

function renderVehicleCard(v) {
  const history   = UTIL_HISTORY[v.id] || [0,0,0,0,0,0,v.utilization];
  const utilColor = v.utilization >= 80 ? 'ok' : v.utilization >= 40 ? 'info' : 'danger';
  const statusColors = { 'on-route':'ok', 'delayed':'danger', 'available':'info', 'maintenance':'warn' };
  const scol       = statusColors[v.status] || 'neutral';
  const icon       = VEHICLE_TYPE_ICONS[v.type] || VEHICLE_TYPE_ICONS['truck'];
  const delayText  = v.delayMin > 0 ? `<span class="badge badge--danger">+${v.delayMin}min</span>` : '';
  const capStr     = v.capacityKg >= 1000 ? (v.capacityKg / 1000).toFixed(0) + ' t' : v.capacityKg + ' kg';

  return `
    <div class="vehicle-card" onclick="showVehicleDetail('${v.id}')">
      <div class="vehicle-card__icon" style="color:var(--brand-primary)">${icon}</div>
      <div class="vehicle-card__info">
        <div class="vehicle-card__id">${v.id} <span class="badge badge--${scol}" style="font-size:.65rem;margin-left:4px">${v.status}</span></div>
        <div class="vehicle-card__route">${v.route}</div>
        <div style="margin-top:4px;font-size:.75rem;color:var(--text-muted)">${v.location}</div>
        <div style="margin-top:4px;font-size:.78rem;color:var(--text-muted)">
          ${v.driver} &bull; ${v.cargo !== '—' ? v.cargo : 'No cargo'} &bull; ETA: ${v.eta}
        </div>
        <div style="margin-top:6px;font-size:.75rem;color:var(--text-muted)">Capacity: ${capStr}</div>
        <div style="margin-top:8px">
          <div style="display:flex;justify-content:space-between;margin-bottom:4px">
            <span style="font-size:.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;font-weight:600">Utilization</span>
            <span style="font-size:.8rem;font-weight:700">${v.utilization}%</span>
          </div>
          <div class="progress-bar">
            <div class="progress-bar__fill progress-bar__fill--${utilColor}" style="width:${v.utilization}%"></div>
          </div>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:8px">
          <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
            <span style="font-size:.72rem;color:var(--text-muted)">⛽ ${v.fuelPct}%</span>
            <span style="font-size:.72rem;color:var(--text-muted)">📦 Load: ${v.load}%</span>
            ${delayText}
          </div>
          ${sparkBars(history, utilColor)}
        </div>
      </div>
    </div>`;
}

function sortFleet(col) {
  if (_fleetSort.col === col) {
    _fleetSort.dir = _fleetSort.dir === 'asc' ? 'desc' : 'asc';
  } else {
    _fleetSort.col = col;
    _fleetSort.dir = 'asc';
  }
  renderFleet();
}

function setFleetFilter(value) {
  const filters = AppState.get('filters');
  filters.fleetStatus = value;
  AppState.set('filters', filters);
  renderFleet();
}

function showVehicleDetail(id) {
  const v = VEHICLES.find(x => x.id === id);
  if (!v) return;
  const capStr = v.capacityKg >= 1000 ? (v.capacityKg / 1000).toFixed(0) + ' tonnes' : v.capacityKg + ' kg';
  showModal(`
    <div style="display:flex;align-items:center;gap:var(--sp-4);margin-bottom:var(--sp-4)">
      <div style="color:var(--brand-primary);width:48px;height:48px;background:var(--bg-elevated);border-radius:var(--radius-md);display:flex;align-items:center;justify-content:center">
        ${VEHICLE_TYPE_ICONS[v.type]}
      </div>
      <div>
        <div style="font-size:1.1rem;font-weight:700">${v.id}</div>
        <div style="font-size:.85rem;color:var(--text-muted)">${v.route}</div>
      </div>
    </div>
    <div class="detail-grid">
      <div class="detail-item"><span class="detail-label">Driver / Operator</span><span>${v.driver}</span></div>
      <div class="detail-item"><span class="detail-label">Current Location</span><span>${v.location}</span></div>
      <div class="detail-item"><span class="detail-label">Status</span>${statusBadge(v.status)}</div>
      <div class="detail-item"><span class="detail-label">Capacity</span><span>${capStr}</span></div>
      <div class="detail-item"><span class="detail-label">Load</span><span>${v.load}%</span></div>
      <div class="detail-item"><span class="detail-label">Utilization</span><span>${v.utilization}%</span></div>
      <div class="detail-item"><span class="detail-label">Fuel Level</span><span style="color:${v.fuelPct<30?'var(--status-danger)':'inherit'}">${v.fuelPct}%</span></div>
      <div class="detail-item"><span class="detail-label">ETA</span><span>${v.eta}</span></div>
      <div class="detail-item"><span class="detail-label">Delay</span><span>${v.delayMin > 0 ? fmtDelay(v.delayMin) : 'On schedule'}</span></div>
      <div class="detail-item"><span class="detail-label">Cargo</span><span>${v.cargo}</span></div>
      <div class="detail-item"><span class="detail-label">Assigned Shipment</span><span class="t-mono">${v.assignedShipment}</span></div>
    </div>
  `, v.id + ' — Vehicle Details');
}
