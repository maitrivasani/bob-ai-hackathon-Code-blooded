/**
 * assistant.js — Decision Assistant (Rule-Based Prototype)
 *
 * Analyses live VEHICLES, SHIPMENTS and DISRUPTIONS data using
 * deterministic rule-based logic and produces prioritised recommendations.
 *
 * IMPORTANT: This is NOT an AI or machine-learning system.
 * It is a rule-based decision-support prototype for demonstration purposes.
 */

/* ══════════════════════════════════════════════════════════
   CORE ANALYSIS ENGINE
   ══════════════════════════════════════════════════════════ */

/**
 * Run full analysis. Returns array of recommendation objects sorted by urgency.
 */
function analyseSupplyChain() {
  const recs = [];

  // Rule 1 — Breakdown / maintenance vehicles with active shipments
  VEHICLES.filter(v => v.status === 'maintenance').forEach(v => {
    const ships = SHIPMENTS.filter(s => s.vehicle === v.id && s.status !== 'delivered');
    if (!ships.length) return;
    const best  = _findBestReplacement(v, ships);
    recs.push({
      id:       'REC-BRKDN-' + v.id,
      urgency:  'critical',
      type:     'breakdown',
      title:    `${v.id} in maintenance — ${ships.length} shipment${ships.length > 1 ? 's' : ''} at risk`,
      summary:  `${v.id} (${v.type}, ${v.location}) is in maintenance and cannot fulfil ${ships.map(s => s.id).join(', ')}.`,
      action:   best
        ? `Reassign to ${best.id} — ${best.location}, ${_pct(best.capacityKg * (1 - best.load / 100))} capacity free, fuel ${best.fuelPct}%.`
        : 'No suitable replacement found. Consider expedited maintenance or third-party carrier.',
      benefit:  best
        ? `Estimated delay reduction: ~55 min. ${ships.filter(s => s.priority === 'critical').length} critical shipment(s) back on schedule.`
        : 'Expedite maintenance to minimise disruption window.',
      affected: { vehicles: [v], shipments: ships, replacement: best },
    });
  });

  // Rule 2 — Delayed vehicles with high/critical shipments
  VEHICLES.filter(v => v.status === 'delayed' && v.delayMin >= 60).forEach(v => {
    const ships = SHIPMENTS.filter(s => s.vehicle === v.id && (s.priority === 'critical' || s.priority === 'high'));
    if (!ships.length) return;
    recs.push({
      id:       'REC-DELAY-' + v.id,
      urgency:  v.delayMin >= 120 ? 'high' : 'medium',
      type:     'delay',
      title:    `${v.id} delayed ${fmtDelay(v.delayMin)} with ${ships.length} high-priority shipment${ships.length > 1 ? 's' : ''}`,
      summary:  `${v.id} is ${fmtDelay(v.delayMin)} behind schedule, carrying ${ships.map(s => s.id + ' (' + s.cargo + ')').join(', ')}.`,
      action:   `Notify receivers. Escalate ${ships.filter(s => s.priority === 'critical').map(s => s.id).join(', ') || 'critical shipments'} for priority handling on arrival. `
              + (v.fuelPct < 35 ? `Fuel level critical (${v.fuelPct}%) — arrange en-route refuel.` : 'Monitor route for further disruptions.'),
      benefit:  `Proactive receiver notification reduces customer impact. Priority offload saves ~15–20 min on delivery completion.`,
      affected: { vehicles: [v], shipments: ships, replacement: null },
    });
  });

  // Rule 3 — Critical disruptions with no recovery action yet
  DISRUPTIONS.filter(d => d.active && d.severity === 'critical').forEach(d => {
    const existingRec = RECOVERY_ACTIONS.find(r => r.disruptionId === d.id);
    const affectedV   = VEHICLES.filter(v => d.affectedVehicles.includes(v.id));
    const affectedS   = SHIPMENTS.filter(s => affectedV.some(v => v.id === s.vehicle));
    recs.push({
      id:       'REC-DIS-' + d.id,
      urgency:  'critical',
      type:     'disruption',
      title:    `Critical disruption: ${d.title}`,
      summary:  `${d.description} Affects ${affectedV.length} vehicle(s) and ${d.impact.shipments} shipments. Est. resolution: ${d.estimatedResolution}.`,
      action:   existingRec
        ? existingRec.title + '. ' + existingRec.description
        : `Activate contingency plan for ${d.affectedRoutes.join(', ')}. Suspend dispatches through affected corridor. Reroute via alternate paths.`,
      benefit:  existingRec
        ? `${existingRec.impact.confidence}% confidence. Estimated delay reduction: ${fmtDelay(existingRec.impact.delayReductionMin)}. Cost delta: ${fmtCurrency(existingRec.impact.costDelta)}.`
        : `Acting within the next hour avoids the full ${d.impact.delayHrs}-hr delay impact on ${d.impact.shipments} shipments.`,
      affected: { vehicles: affectedV, shipments: affectedS, replacement: null },
      revenueRisk: d.impact.revenueAtRisk,
    });
  });

  // Rule 4 — High-risk shipments with no active disruption match
  const highRiskUnlinked = SHIPMENTS.filter(s => {
    const isLinked = DISRUPTIONS.some(d => d.active && d.affectedVehicles.some(vid =>
      VEHICLES.find(v => v.id === vid && v.assignedShipment === s.id)
    ));
    return s.risk === 'high' && !isLinked;
  });
  if (highRiskUnlinked.length > 0) {
    recs.push({
      id:      'REC-RISK-UNLINKED',
      urgency: 'medium',
      type:    'risk',
      title:   `${highRiskUnlinked.length} high-risk shipment${highRiskUnlinked.length > 1 ? 's' : ''} without active disruption coverage`,
      summary: `${highRiskUnlinked.map(s => s.id + ' (' + s.cargo + ')').join(', ')} are flagged high-risk but not currently covered by a disruption recovery plan.`,
      action:  'Review each shipment\'s route for emerging disruption risk. '
             + 'Consider pre-emptive rerouting or escalation to ensure on-time delivery.',
      benefit: 'Early intervention prevents reactive disruption response. Reduces probability of SLA breach.',
      affected: { vehicles: [], shipments: highRiskUnlinked, replacement: null },
    });
  }

  // Rule 5 — Underutilised available vehicles while delayed shipments exist
  const availableVehicles = VEHICLES.filter(v => v.status === 'available' && v.load === 0);
  const delayedShipments  = SHIPMENTS.filter(s => s.status === 'delayed' || s.status === 'at-risk');
  if (availableVehicles.length > 0 && delayedShipments.length > 0) {
    const matchable = delayedShipments.filter(s => {
      const v = availableVehicles.find(av => av.capacityKg >= s.weightKg);
      return !!v;
    });
    if (matchable.length > 0) {
      const bestV = availableVehicles.sort((a, b) => b.capacityKg - a.capacityKg)[0];
      recs.push({
        id:      'REC-UTIL-OPP',
        urgency: 'low',
        type:    'utilization',
        title:   `${availableVehicles.length} idle vehicle${availableVehicles.length > 1 ? 's' : ''} could cover ${matchable.length} delayed shipment${matchable.length > 1 ? 's' : ''}`,
        summary: `${availableVehicles.map(v => v.id).join(', ')} ${availableVehicles.length > 1 ? 'are' : 'is'} fully available (0% load) while ${matchable.map(s => s.id).join(', ')} ${matchable.length > 1 ? 'are' : 'is'} delayed or at risk.`,
        action:  `Assign ${bestV.id} (${bestV.location}, ${_pct(bestV.capacityKg)} capacity, fuel ${bestV.fuelPct}%) to cover ${matchable[0].id} (${matchable[0].origin} → ${matchable[0].dest}).`
               + (matchable.length > 1 ? ` Evaluate further matches for ${matchable.slice(1).map(s => s.id).join(', ')}.` : ''),
        benefit: `Improves fleet utilization from ${_avgUtilPublic()}% toward target. Reduces delays on ${matchable.length} shipment${matchable.length > 1 ? 's' : ''}.`,
        affected: { vehicles: availableVehicles, shipments: matchable, replacement: bestV },
      });
    }
  }

  // Rule 6 — Low fuel on active vehicles
  VEHICLES.filter(v => v.status === 'on-route' && v.fuelPct < 30).forEach(v => {
    const ship = SHIPMENTS.find(s => s.vehicle === v.id);
    recs.push({
      id:      'REC-FUEL-' + v.id,
      urgency: v.fuelPct < 15 ? 'high' : 'medium',
      type:    'fuel',
      title:   `${v.id} fuel critical at ${v.fuelPct}% — risk of en-route stoppage`,
      summary: `${v.id} is on route (${v.route}) at ${v.fuelPct}% fuel. ${ship ? 'Carrying ' + ship.cargo + ' for ' + ship.id + '.' : ''}`,
      action:  `Dispatch refuel team or reroute ${v.id} to nearest fuel point en route. Do not allow departure below 20% if stopped.`,
      benefit: `Prevents en-route breakdown. Maintains ${ship ? ship.id + ' ETA of ' + ship.eta : 'delivery schedule'}.`,
      affected: { vehicles: [v], shipments: ship ? [ship] : [], replacement: null },
    });
  });

  // Sort: critical first, then high, medium, low; break ties by revenue risk
  const urgencyOrder = { critical: 0, high: 1, medium: 2, low: 3 };
  recs.sort((a, b) => {
    const u = urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
    if (u !== 0) return u;
    return (b.revenueRisk || 0) - (a.revenueRisk || 0);
  });

  return recs;
}

/* ── Small helpers internal to assistant ──────────────────── */
function _findBestReplacement(brokenVehicle, shipments) {
  const maxWeight = Math.max(...shipments.map(s => s.weightKg), 0);
  return VEHICLES
    .filter(v =>
      v.id !== brokenVehicle.id &&
      v.status === 'available'  &&
      v.capacityKg >= maxWeight
    )
    .sort((a, b) => a.load - b.load)[0] || null;
}

function _pct(kg) {
  return kg >= 1000 ? (kg / 1000).toFixed(0) + ' t' : kg + ' kg';
}

function _avgUtilPublic() {
  return Math.round(VEHICLES.reduce((s, v) => s + v.utilization, 0) / VEHICLES.length);
}

/* ══════════════════════════════════════════════════════════
   RENDER
   ══════════════════════════════════════════════════════════ */

function renderAssistant() {
  const view = document.getElementById('view-assistant');
  const recs = analyseSupplyChain();

  const urgencyCount = {
    critical: recs.filter(r => r.urgency === 'critical').length,
    high:     recs.filter(r => r.urgency === 'high').length,
    medium:   recs.filter(r => r.urgency === 'medium').length,
    low:      recs.filter(r => r.urgency === 'low').length,
  };

  view.innerHTML = `
    <div class="page-header">
      <div class="page-header__meta">
        <div class="page-header__title">Decision Assistant</div>
        <div class="page-header__sub">
          Rule-based decision support — prototype. Analysis drawn from live fleet, shipment &amp; disruption data.
          <span class="badge badge--neutral" style="margin-left:8px">Not AI / No ML backend</span>
        </div>
      </div>
      <div class="page-header__controls">
        <button class="btn btn--primary" onclick="renderAssistant()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>
          Refresh Analysis
        </button>
      </div>
    </div>

    <!-- Summary strip -->
    <div class="stat-row">
      <div class="stat-row__item">
        <span class="stat-row__label">Critical</span>
        <span class="stat-row__value" style="color:var(--sev-critical)">${urgencyCount.critical}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">High</span>
        <span class="stat-row__value" style="color:var(--sev-high)">${urgencyCount.high}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">Medium</span>
        <span class="stat-row__value" style="color:#7a5f00">${urgencyCount.medium}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">Low</span>
        <span class="stat-row__value">${urgencyCount.low}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">Total Recommendations</span>
        <span class="stat-row__value">${recs.length}</span>
      </div>
    </div>

    <!-- How it works notice -->
    <div class="assistant-notice">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
      <span>
        <strong>How this works:</strong> The assistant scans the current fleet for breakdowns, delayed high-priority vehicles, critical disruptions, unlinked high-risk shipments, idle vehicles with available capacity, and low-fuel warnings. Each recommendation is generated from the data — not from fixed templates.
      </span>
    </div>

    ${recs.length === 0 ? `
      <div class="empty-state" style="margin-top:var(--sp-6)">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" opacity=".3"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
        <div class="empty-state__title">No recommendations at this time</div>
        <div class="empty-state__body">All vehicles and shipments are operating normally.</div>
      </div>` : `
      <div class="assistant-list">
        ${recs.map(r => renderAssistantRec(r)).join('')}
      </div>`}
  `;
}

function renderAssistantRec(r) {
  const urgencyColors = { critical: 'danger', high: 'warn', medium: 'info', low: 'neutral' };
  const typeIcons = {
    breakdown:   'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z',
    delay:       'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
    disruption:  'M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z',
    risk:        'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z',
    utilization: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z',
    fuel:        'M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3',
  };
  const ucol = urgencyColors[r.urgency] || 'neutral';
  const icon = typeIcons[r.type] || typeIcons.risk;

  const hasReplacement = r.affected.replacement;
  const vehicles = r.affected.vehicles || [];
  const shipments = r.affected.shipments || [];

  return `
    <div class="assistant-rec assistant-rec--${r.urgency}" id="${r.id}">
      <div class="assistant-rec__header">
        <div class="assistant-rec__icon-col">
          <div class="assistant-rec__type-icon">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="${icon}"/>${r.type === 'breakdown' ? '<circle cx="12" cy="12" r="3"/>' : ''}
            </svg>
          </div>
          <div class="assistant-rec__sev-bar assistant-rec__sev-bar--${r.urgency}"></div>
        </div>
        <div class="assistant-rec__body">
          <div class="assistant-rec__title-row">
            <span class="assistant-rec__title">${r.title}</span>
            <span class="badge badge--${ucol}">${r.urgency}</span>
          </div>
          <div class="assistant-rec__summary">${r.summary}</div>

          <div class="decision-block" style="margin-top:var(--sp-3)">
            <div class="decision-block__section">
              <div class="decision-block__label decision-block__label--action">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                Recommended Action
              </div>
              <div class="decision-block__text">${r.action}</div>
            </div>
            <div class="decision-block__section">
              <div class="decision-block__label decision-block__label--benefit">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>
                Expected Benefit
              </div>
              <div class="decision-block__text">${r.benefit}</div>
            </div>
          </div>

          ${vehicles.length > 0 || shipments.length > 0 ? `
          <div class="assistant-rec__tags">
            ${vehicles.map(v => `<span class="badge badge--neutral" style="font-family:monospace">${v.id}</span>`).join('')}
            ${shipments.slice(0, 4).map(s => `<span class="badge badge--neutral" style="font-family:monospace">${s.id}</span>`).join('')}
            ${shipments.length > 4 ? `<span class="badge badge--neutral">+${shipments.length - 4} more</span>` : ''}
            ${hasReplacement ? `<span class="badge badge--ok">→ ${hasReplacement.id}</span>` : ''}
            ${r.revenueRisk ? `<span class="badge badge--danger">${fmtCurrency(r.revenueRisk)} at risk</span>` : ''}
          </div>` : ''}
        </div>
      </div>
    </div>
  `;
}

/* ── Dashboard mini-panel (shown on dashboard view) ────────── */
function renderAssistantMini() {
  const recs = analyseSupplyChain();
  const top  = recs.slice(0, 3);
  if (top.length === 0) {
    return `<div class="empty-state" style="padding:var(--sp-5)">
      <div class="empty-state__title">No active recommendations</div>
    </div>`;
  }
  const urgencyColors = { critical: 'danger', high: 'warn', medium: 'info', low: 'neutral' };
  return top.map(r => `
    <div class="feed-item" onclick="navigateTo('assistant')" style="cursor:pointer">
      <div class="feed-item__icon-col">
        <div class="feed-item__dot dot--${urgencyColors[r.urgency] || 'info'}"></div>
        ${top.indexOf(r) < top.length - 1 ? '<div class="feed-item__line"></div>' : ''}
      </div>
      <div class="feed-item__body">
        <div class="feed-item__title">${r.title}</div>
        <div class="feed-item__desc">${r.action.substring(0, 100)}${r.action.length > 100 ? '…' : ''}</div>
        <div class="feed-item__meta">
          <span class="badge badge--${urgencyColors[r.urgency]}">${r.urgency}</span>
          <span class="badge badge--neutral">${r.type}</span>
        </div>
      </div>
    </div>
  `).join('');
}
