/**
 * simulator.js — What-If Scenario Simulator
 * Data-driven: reads actual VEHICLES, SHIPMENTS, DISRUPTIONS.
 * Five concrete scenarios with Before/After comparison and
 * a plain-language decision explanation per simulation.
 *
 * NOTE: All logic is rule-based JavaScript prototype logic.
 * No AI/ML backend is used or implied.
 */

/* ─── helpers shared by simulator ──────────────────────────── */
function _avgUtil(vehicles) {
  if (!vehicles.length) return 0;
  return Math.round(vehicles.reduce((s, v) => s + v.utilization, 0) / vehicles.length);
}

function _onTimePct(shipments) {
  if (!shipments.length) return 0;
  return Math.round(shipments.filter(s => s.status === 'on-time').length / shipments.length * 100);
}

function _capStr(kg) {
  return kg >= 1000 ? (kg / 1000).toFixed(0) + ' t' : kg + ' kg';
}

/* ─── Scenario engines ──────────────────────────────────────── */

function _simBreakdown(params) {
  /* Pick the vehicle with the worst fuel + highest delay, or let user specify */
  const target = VEHICLES.find(v => v.id === params.targetVehicle)
    || VEHICLES.filter(v => v.status === 'delayed')
        .sort((a, b) => b.delayMin - a.delayMin)[0]
    || VEHICLES[0];

  const affectedShipments = SHIPMENTS.filter(s => s.vehicle === target.id);
  const criticalShipments = affectedShipments.filter(s => s.priority === 'critical' || s.priority === 'high');

  /* Find best replacement: available, sufficient capacity, lowest current load */
  const candidates = VEHICLES.filter(v =>
    v.id !== target.id &&
    v.status === 'available' &&
    v.capacityKg >= Math.max(...affectedShipments.map(s => s.weightKg), 0)
  ).sort((a, b) => a.load - b.load);

  const best = candidates[0] || null;

  const baseDelayMin   = target.delayMin + 90; // breakdown adds ~90 min base
  const reassignDelay  = best ? 35 : 180;       // reassignment saves ~55 min
  const finalDelayMin  = best ? reassignDelay : baseDelayMin;

  const beforeUtil = _avgUtil(VEHICLES);
  const afterUtil  = best
    ? Math.round(beforeUtil - (target.utilization / VEHICLES.length) + (best.utilization + 20) / VEHICLES.length)
    : Math.round(beforeUtil - target.utilization / VEHICLES.length);

  const beforeOnTime = _onTimePct(SHIPMENTS);
  const afterOnTime  = best
    ? Math.max(beforeOnTime - Math.round(criticalShipments.length * 4), beforeOnTime - 8)
    : Math.max(beforeOnTime - Math.round(affectedShipments.length * 8), 0);

  const revenueRisk = affectedShipments.reduce((s, sh) => s + sh.value, 0);

  return {
    scenarioLabel: 'Vehicle Breakdown',
    affectedVehicles:  [target],
    affectedShipments,
    criticalShipments,
    bestReplacement:   best,
    allCandidates:     candidates,
    baseDelayMin,
    finalDelayMin,
    beforeUtil,
    afterUtil,
    beforeOnTime,
    afterOnTime,
    beforeAtRisk:  SHIPMENTS.filter(s => s.risk === 'high').length,
    afterAtRisk:   SHIPMENTS.filter(s => s.risk === 'high').length + (best ? 0 : affectedShipments.length),
    revenueRisk,
    impact: `${target.id} is unavailable${target.cargo !== '—' ? ', carrying ' + target.cargo : ''}. `
          + `${affectedShipments.length} shipment${affectedShipments.length !== 1 ? 's are' : ' is'} affected, `
          + `adding an estimated ${baseDelayMin} min delay without intervention.`,
    action: best
      ? `Reassign ${affectedShipments.map(s => s.id).join(', ')} to ${best.id} (${best.location}). `
        + `${best.id} has ${_capStr(best.capacityKg)} capacity at ${best.load}% load — sufficient for all affected cargo. `
        + `${best.type} selected over ${candidates.length - 1} other candidate${candidates.length !== 2 ? 's' : ''} due to lowest current load.`
      : `No fully available vehicle with matching capacity was found. Consider partial reassignment or expedited maintenance on ${target.id}.`,
    benefit: best
      ? `Estimated delay reduced from ~${baseDelayMin} min to ~${finalDelayMin} min (~${Math.round((1 - finalDelayMin / baseDelayMin) * 100)}% reduction). `
        + `Fleet utilization impact minimised. ${criticalShipments.length > 0 ? criticalShipments.length + ' critical shipment(s) remain on schedule.' : ''}`
      : `Without reassignment, on-time delivery rate drops ~${beforeOnTime - afterOnTime}%. Expedite maintenance to recover.`,
  };
}

function _simRoadClosure(params) {
  const sevMult = { low: 0.3, medium: 0.55, high: 0.8, critical: 1.0 }[params.severity] || 0.6;
  const closureRoutes = DISRUPTIONS.filter(d => d.type === 'traffic' && d.active)
    .flatMap(d => d.affectedRoutes);

  const affectedVehicles = VEHICLES.filter(v =>
    DISRUPTIONS.some(d => d.type === 'traffic' && d.active && d.affectedVehicles.includes(v.id))
  );

  const affectedShipments = SHIPMENTS.filter(s =>
    affectedVehicles.some(v => v.id === s.vehicle)
  );

  const addedDelayMin  = Math.round(45 + params.durationHrs * 8 * sevMult);
  const highPriority   = affectedShipments.filter(s => s.priority === 'critical' || s.priority === 'high');
  const reroutable     = affectedVehicles.filter(v => v.status === 'on-route');

  const beforeUtil     = _avgUtil(VEHICLES);
  const afterUtil      = Math.max(beforeUtil - Math.round(sevMult * 12), 0);
  const beforeOnTime   = _onTimePct(SHIPMENTS);
  const afterOnTime    = Math.max(beforeOnTime - Math.round(affectedShipments.length * 5 * sevMult), 0);

  return {
    scenarioLabel: 'Road Closure',
    affectedVehicles,
    affectedShipments,
    criticalShipments: highPriority,
    bestReplacement:   null,
    addedDelayMin,
    finalDelayMin:     addedDelayMin,
    beforeUtil, afterUtil, beforeOnTime, afterOnTime,
    beforeAtRisk: SHIPMENTS.filter(s => s.risk === 'high').length,
    afterAtRisk:  SHIPMENTS.filter(s => s.risk === 'high').length + highPriority.length,
    revenueRisk:  affectedShipments.reduce((s, sh) => s + sh.value, 0),
    closureRoutes,
    impact: `${closureRoutes.length > 0 ? closureRoutes.slice(0, 2).join(' and ') + ' affected.' : 'Selected routes blocked.'} `
          + `${affectedVehicles.length} vehicle${affectedVehicles.length !== 1 ? 's' : ''} impacted, `
          + `adding ~${addedDelayMin} min to affected deliveries.`,
    action: reroutable.length > 0
      ? `Activate alternate routing for ${reroutable.map(v => v.id).join(', ')}. `
        + `Prioritise ${highPriority.length > 0 ? highPriority.map(s => s.id).join(', ') : 'high-value shipments'} with time-sensitive rerouting. `
        + `Time-shift non-urgent deliveries to off-peak windows where possible.`
      : 'Hold dispatches until route clearance is confirmed. Pre-position available vehicles at alternate staging points.',
    benefit: `Dynamic rerouting can reduce average delay by 40–55%. `
           + `On-time rate recovers from ${afterOnTime}% to ~${Math.min(beforeOnTime, afterOnTime + 10)}% within 2 hrs of reroute activation.`,
  };
}

function _simHeavyTraffic(params) {
  const sevMult   = { low: 0.2, medium: 0.4, high: 0.65, critical: 0.85 }[params.severity] || 0.4;
  const addedMin  = Math.round(20 + params.durationHrs * 5 * sevMult);

  const enRoute   = VEHICLES.filter(v => v.status === 'on-route');
  const affected  = enRoute.slice(0, Math.max(1, Math.round(enRoute.length * sevMult)));
  const affShip   = SHIPMENTS.filter(s => affected.some(v => v.id === s.vehicle));
  const nowLate   = affShip.filter(s => s.status === 'on-time');

  const beforeUtil  = _avgUtil(VEHICLES);
  const afterUtil   = Math.max(beforeUtil - Math.round(sevMult * 8), 0);
  const beforeOnTime= _onTimePct(SHIPMENTS);
  const afterOnTime = Math.max(beforeOnTime - Math.round(nowLate.length / SHIPMENTS.length * 100), 0);

  return {
    scenarioLabel: 'Heavy Traffic',
    affectedVehicles:  affected,
    affectedShipments: affShip,
    criticalShipments: affShip.filter(s => s.priority === 'critical'),
    bestReplacement:   null,
    addedDelayMin:     addedMin,
    finalDelayMin:     addedMin,
    beforeUtil, afterUtil, beforeOnTime, afterOnTime,
    beforeAtRisk: SHIPMENTS.filter(s => s.risk === 'high').length,
    afterAtRisk:  SHIPMENTS.filter(s => s.risk === 'high').length + nowLate.filter(s => s.priority !== 'low').length,
    revenueRisk:  affShip.reduce((s, sh) => s + sh.value, 0),
    impact: `Heavy congestion adds ~${addedMin} min to ${affected.length} active vehicle${affected.length !== 1 ? 's' : ''}. `
          + `${nowLate.length} on-time shipment${nowLate.length !== 1 ? 's' : ''} likely to miss ETA.`,
    action: `Push GPS route updates to ${affected.map(v => v.id).join(', ')}. `
          + `Time-shift ${affShip.filter(s => s.priority === 'low').length} low-priority shipment${affShip.filter(s => s.priority === 'low').length !== 1 ? 's' : ''} to off-peak (22:00–05:00). `
          + `Notify receivers of estimated ${addedMin}-min delay.`,
    benefit: `Real-time rerouting recovers ~40% of delay. On-time rate stabilises at ~${Math.min(beforeOnTime, afterOnTime + 8)}%.`,
  };
}

function _simWeather(params) {
  const sevMult  = { low: 0.25, medium: 0.5, high: 0.75, critical: 1.0 }[params.severity] || 0.5;
  const addedHrs = Math.round(params.durationHrs * 0.6 * sevMult * 10) / 10;

  const weatherDis    = DISRUPTIONS.filter(d => d.type === 'weather' && d.active);
  const affectedVIds  = [...new Set(weatherDis.flatMap(d => d.affectedVehicles))];
  const affectedV     = VEHICLES.filter(v => affectedVIds.includes(v.id));
  // Deterministic: include on-route vehicles with lowest fuel (most vulnerable)
  const additionalCount = Math.round(VEHICLES.length * sevMult * 0.3);
  const additionalV   = VEHICLES.filter(v =>
    v.status === 'on-route' && !affectedVIds.includes(v.id)
  ).sort((a, b) => a.fuelPct - b.fuelPct).slice(0, additionalCount);

  const allAffected   = [...affectedV, ...additionalV];
  const affShip       = SHIPMENTS.filter(s => allAffected.some(v => v.id === s.vehicle));
  const highPri       = affShip.filter(s => s.priority === 'critical' || s.priority === 'high');

  const beforeUtil    = _avgUtil(VEHICLES);
  const afterUtil     = Math.max(beforeUtil - Math.round(sevMult * 18), 0);
  const beforeOnTime  = _onTimePct(SHIPMENTS);
  const afterOnTime   = Math.max(beforeOnTime - Math.round(affShip.length / SHIPMENTS.length * 100 * 1.3), 0);

  const suspendedRoutes = weatherDis.flatMap(d => d.affectedRoutes);

  return {
    scenarioLabel: 'Severe Weather',
    affectedVehicles: allAffected,
    affectedShipments: affShip,
    criticalShipments: highPri,
    bestReplacement: null,
    addedDelayMin: Math.round(addedHrs * 60),
    finalDelayMin: Math.round(addedHrs * 60),
    beforeUtil, afterUtil, beforeOnTime, afterOnTime,
    beforeAtRisk: SHIPMENTS.filter(s => s.risk === 'high').length,
    afterAtRisk:  SHIPMENTS.filter(s => s.risk === 'high').length + highPri.length,
    revenueRisk:  affShip.reduce((s, sh) => s + sh.value, 0) + weatherDis.reduce((s, d) => s + d.impact.revenueAtRisk, 0),
    suspendedRoutes,
    impact: `${weatherDis.length > 0 ? weatherDis[0].title + ' causes' : 'Severe weather causes'} `
          + `${allAffected.length} vehicle suspension${allAffected.length !== 1 ? 's' : ''} and ~${addedHrs} hr delay across ${affShip.length} shipments. `
          + (suspendedRoutes.length > 0 ? suspendedRoutes.slice(0, 2).join(', ') + ' suspended.' : ''),
    action: highPri.length > 0
      ? `Immediately reroute ${highPri.map(s => s.id).join(', ')} via inland corridors away from affected zones. `
        + `Hold non-critical dispatches until ${params.durationHrs}h weather window passes. `
        + 'Activate standby vehicles in unaffected depots for priority shipments.'
      : 'Hold all dispatches through affected corridor. Monitor weather window and pre-stage vehicles at safe depots.',
    benefit: `Inland rerouting reduces exposure by ~60%. Priority shipments recover ~${Math.round(addedHrs * 0.4 * 60)} min of delay. `
           + `Fleet utilization recovers to ~${Math.min(beforeUtil, afterUtil + 10)}% once weather window passes.`,
  };
}

function _simDemandSpike(params) {
  const spikeRatio = { low: 1.2, medium: 1.5, high: 2.0, critical: 2.8 }[params.severity] || 1.5;
  const extraShipCount = Math.round(SHIPMENTS.length * (spikeRatio - 1));
  const totalShipments = SHIPMENTS.length + extraShipCount;

  const availableVehicles = VEHICLES.filter(v => v.status === 'available');
  const underloaded       = VEHICLES.filter(v => v.status === 'on-route' && v.load < 60)
    .sort((a, b) => a.load - b.load);

  const totalCapacityFree = availableVehicles.reduce((s, v) => s + (v.capacityKg * (1 - v.load / 100)), 0)
    + underloaded.reduce((s, v) => s + (v.capacityKg * ((60 - v.load) / 100)), 0);

  const avgShipWeight = Math.round(SHIPMENTS.reduce((s, sh) => s + sh.weightKg, 0) / SHIPMENTS.length);
  const extraWeightKg = extraShipCount * avgShipWeight;
  const canAbsorb     = totalCapacityFree >= extraWeightKg;
  const shortfallKg   = Math.max(0, extraWeightKg - totalCapacityFree);

  const beforeUtil    = _avgUtil(VEHICLES);
  const afterUtil     = Math.min(99, Math.round(beforeUtil + (spikeRatio - 1) * 18));
  const beforeOnTime  = _onTimePct(SHIPMENTS);
  const afterOnTime   = canAbsorb
    ? Math.max(beforeOnTime - 6, 70)
    : Math.max(beforeOnTime - Math.round((1 - totalCapacityFree / extraWeightKg) * 30), 50);

  const allocationPlan = [
    ...availableVehicles.map(v => ({ vehicle: v, action: 'Dispatch from ' + v.location, extraLoad: Math.round(v.capacityKg * 0.7) })),
    ...underloaded.slice(0, 3).map(v => ({ vehicle: v, action: 'Consolidate load on ' + v.id, extraLoad: Math.round(v.capacityKg * (0.6 - v.load / 100)) })),
  ];

  return {
    scenarioLabel: 'Demand Spike',
    affectedVehicles: VEHICLES,
    affectedShipments: SHIPMENTS,
    criticalShipments: SHIPMENTS.filter(s => s.priority === 'critical'),
    bestReplacement: availableVehicles[0] || null,
    addedDelayMin: canAbsorb ? 20 : 75,
    finalDelayMin: canAbsorb ? 20 : 75,
    beforeUtil, afterUtil, beforeOnTime, afterOnTime,
    beforeAtRisk: SHIPMENTS.filter(s => s.risk === 'high').length,
    afterAtRisk:  canAbsorb ? SHIPMENTS.filter(s => s.risk === 'high').length + 1 : SHIPMENTS.filter(s => s.risk === 'high').length + 4,
    revenueRisk:  Math.round(extraShipCount * 25000 * (canAbsorb ? 0.15 : 0.45)),
    extraShipCount, totalShipments, totalCapacityFree, shortfallKg, canAbsorb, allocationPlan,
    impact: `+${Math.round((spikeRatio - 1) * 100)}% demand spike adds ${extraShipCount} simulated shipments (~${(extraWeightKg / 1000).toFixed(0)} tonnes). `
          + (canAbsorb
              ? `Current fleet can absorb this with ${(totalCapacityFree / 1000).toFixed(0)} t free capacity.`
              : `Fleet is ${(shortfallKg / 1000).toFixed(0)} t short of capacity. Service level risk is high.`),
    action: canAbsorb
      ? `Dispatch ${availableVehicles.length} available vehicle${availableVehicles.length !== 1 ? 's' : ''}: ${availableVehicles.map(v => v.id).join(', ')}. `
        + `Consolidate loads on ${underloaded.slice(0, 2).map(v => v.id).join(', ')} (currently under 60% load). `
        + 'Prioritise critical and high-priority shipments for first dispatch wave.'
      : `Immediate actions: dispatch all ${availableVehicles.length} available vehicles and consolidate underloaded fleet. `
        + `Shortfall of ${(shortfallKg / 1000).toFixed(0)} t requires external carrier agreements or deferred low-priority shipments.`,
    benefit: canAbsorb
      ? `Fleet utilization rises to ~${afterUtil}% — efficient use of spare capacity. On-time rate maintained at ~${afterOnTime}%.`
      : `Partial mitigation: available fleet absorbs ~${Math.round(totalCapacityFree / extraWeightKg * 100)}% of spike. `
        + `On-time rate projected at ${afterOnTime}% vs ${beforeOnTime}% baseline without intervention.`,
    allocationPlan,
  };
}

/* ─── Main simulation dispatcher ───────────────────────────── */
function runSimulation() {
  const sim = AppState.get('simulator');
  let result;

  switch (sim.disruptionType) {
    case 'breakdown':        result = _simBreakdown(sim);    break;
    case 'traffic':          result = _simRoadClosure(sim);  break;
    case 'heavy-traffic':    result = _simHeavyTraffic(sim); break;
    case 'weather':          result = _simWeather(sim);      break;
    case 'demand-spike':     result = _simDemandSpike(sim);  break;
    default:                 result = _simRoadClosure(sim);
  }

  result.severity    = sim.severity;
  result.durationHrs = sim.durationHrs;
  result.type        = sim.disruptionType;

  AppState.set('simulator', { ...sim, result });
  document.getElementById('sim-output').innerHTML = renderSimResults(result);
}

/* ─── Render ────────────────────────────────────────────────── */
function renderSimulator() {
  const view = document.getElementById('view-simulator');
  const sim  = AppState.get('simulator');

  view.innerHTML = `
    <div class="page-header">
      <div class="page-header__meta">
        <div class="page-header__title">What-If Scenario Simulator</div>
        <div class="page-header__sub">Rule-based prototype — no AI backend. Logic reads live fleet, shipment &amp; disruption data.</div>
      </div>
    </div>

    <div class="sim-panel">
      <div class="sim-panel__toolbar">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#f4f4f4" stroke-width="2">
          <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
        </svg>
        <span class="sim-panel__label">Scenario Simulator — Prototype</span>
        <button class="btn btn--primary" onclick="runSimulation()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
          Run Simulation
        </button>
        <button class="btn btn--ghost" style="color:rgba(255,255,255,.6);border-color:rgba(255,255,255,.15)" onclick="resetSimulator()">Reset</button>
      </div>

      <div class="sim-results">
        <div class="form-grid">
          <div class="form-field">
            <label>Scenario Type</label>
            <select class="form-select" id="sim-type" onchange="updateSimParam('disruptionType', this.value)">
              <option value="breakdown"     ${sim.disruptionType==='breakdown'?'selected':''}>Vehicle Breakdown</option>
              <option value="traffic"       ${sim.disruptionType==='traffic'?'selected':''}>Road Closure</option>
              <option value="heavy-traffic" ${sim.disruptionType==='heavy-traffic'?'selected':''}>Heavy Traffic</option>
              <option value="weather"       ${sim.disruptionType==='weather'?'selected':''}>Severe Weather</option>
              <option value="demand-spike"  ${sim.disruptionType==='demand-spike'?'selected':''}>Demand Spike</option>
            </select>
          </div>
          <div class="form-field">
            <label>Severity</label>
            <select class="form-select" id="sim-severity" onchange="updateSimParam('severity', this.value)">
              <option value="low"      ${sim.severity==='low'?'selected':''}>Low</option>
              <option value="medium"   ${sim.severity==='medium'?'selected':''}>Medium</option>
              <option value="high"     ${sim.severity==='high'?'selected':''}>High</option>
              <option value="critical" ${sim.severity==='critical'?'selected':''}>Critical</option>
            </select>
          </div>
          ${sim.disruptionType === 'breakdown' ? `
          <div class="form-field">
            <label>Target Vehicle</label>
            <select class="form-select" id="sim-target-vehicle" onchange="updateSimParam('targetVehicle', this.value)">
              <option value="">— Auto-select worst-case —</option>
              ${VEHICLES.map(v => `<option value="${v.id}" ${sim.targetVehicle===v.id?'selected':''}>${v.id} (${v.status}, ${v.location})</option>`).join('')}
            </select>
          </div>` : ''}
          <div class="form-field">
            <label>Event Duration: <strong id="sim-duration-label">${sim.durationHrs}h</strong></label>
            <input type="range" class="form-range" id="sim-duration" min="1" max="120"
              value="${sim.durationHrs}"
              oninput="document.getElementById('sim-duration-label').textContent=this.value+'h'; updateSimParam('durationHrs', +this.value)">
          </div>
        </div>

        <div id="sim-output">
          ${sim.result ? renderSimResults(sim.result) : renderSimPlaceholder()}
        </div>
      </div>
    </div>
  `;
}

function renderSimPlaceholder() {
  return `
    <div class="empty-state" style="padding:var(--sp-8)">
      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" opacity=".3">
        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
      </svg>
      <div class="empty-state__title">Select a scenario and click Run Simulation</div>
      <div class="empty-state__body">The simulator reads your live fleet and shipment data to calculate realistic impact, show a Before vs After comparison, and recommend the best corrective action.</div>
    </div>`;
}

function renderSimResults(r) {
  const sevColors  = { low:'ok', medium:'warn', high:'danger', critical:'danger' };
  const scol       = sevColors[r.severity] || 'info';
  const beforeUtil = r.beforeUtil;
  const afterUtil  = r.afterUtil;
  const utilDelta  = afterUtil - beforeUtil;
  const onTimeDelta= r.afterOnTime - r.beforeOnTime;

  return `
    <!-- Scenario badge -->
    <div style="display:flex;align-items:center;gap:var(--sp-3);margin-bottom:var(--sp-5);flex-wrap:wrap">
      <span class="badge badge--${scol}" style="font-size:.82rem;padding:5px 12px;font-weight:700">
        ${r.severity.toUpperCase()} SEVERITY
      </span>
      <span class="badge badge--neutral" style="font-size:.82rem;padding:5px 12px">
        ${r.scenarioLabel}
      </span>
      <span style="font-size:.82rem;color:var(--text-muted)">${r.durationHrs}h event · ${r.affectedVehicles.length} vehicle(s) · ${r.affectedShipments.length} shipment(s)</span>
    </div>

    <!-- Before vs After table -->
    <div class="bva-section">
      <div class="bva-header">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
        Before vs After Comparison
      </div>
      <div class="bva-table-wrap">
        <table class="bva-table">
          <thead>
            <tr><th>Metric</th><th>Before</th><th>After</th><th>Change</th></tr>
          </thead>
          <tbody>
            ${_bvaRow('Fleet Utilization',  beforeUtil + '%',    afterUtil + '%',    utilDelta,      '%',  true)}
            ${_bvaRow('On-Time Delivery',   r.beforeOnTime+'%',  r.afterOnTime+'%',  onTimeDelta,    '%',  true)}
            ${_bvaRow('At-Risk Shipments',  r.beforeAtRisk,      r.afterAtRisk,      r.afterAtRisk - r.beforeAtRisk, '', false)}
            ${_bvaRow('Affected Shipments', 0,                   r.affectedShipments.length, r.affectedShipments.length, '', false)}
            ${_bvaRow('Est. Added Delay',   '0 min',             r.finalDelayMin + ' min', r.finalDelayMin, 'min', false)}
            ${_bvaRow('Revenue at Risk',    '$0',                fmtCurrency(r.revenueRisk), null, '', false)}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Utilization bar comparison -->
    <div class="bva-bars">
      <div class="bva-bar-item">
        <div class="bva-bar-label">Fleet Utilization — Before</div>
        <div class="bva-bar-track">
          <div class="bva-bar-fill bva-bar-fill--before" style="width:${beforeUtil}%"></div>
        </div>
        <span class="bva-bar-pct">${beforeUtil}%</span>
      </div>
      <div class="bva-bar-item">
        <div class="bva-bar-label">Fleet Utilization — After</div>
        <div class="bva-bar-track">
          <div class="bva-bar-fill bva-bar-fill--after" style="width:${Math.max(afterUtil, 2)}%"></div>
        </div>
        <span class="bva-bar-pct">${afterUtil}%</span>
      </div>
      <div class="bva-bar-item">
        <div class="bva-bar-label">On-Time Rate — Before</div>
        <div class="bva-bar-track">
          <div class="bva-bar-fill bva-bar-fill--before" style="width:${r.beforeOnTime}%"></div>
        </div>
        <span class="bva-bar-pct">${r.beforeOnTime}%</span>
      </div>
      <div class="bva-bar-item">
        <div class="bva-bar-label">On-Time Rate — After</div>
        <div class="bva-bar-track">
          <div class="bva-bar-fill bva-bar-fill--after" style="width:${Math.max(r.afterOnTime, 2)}%"></div>
        </div>
        <span class="bva-bar-pct">${r.afterOnTime}%</span>
      </div>
    </div>

    <!-- Decision explanation -->
    <div class="decision-block">
      <div class="decision-block__section">
        <div class="decision-block__label">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          Impact
        </div>
        <div class="decision-block__text">${r.impact}</div>
      </div>
      <div class="decision-block__section">
        <div class="decision-block__label decision-block__label--action">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          Recommended Action
        </div>
        <div class="decision-block__text">${r.action}</div>
      </div>
      <div class="decision-block__section">
        <div class="decision-block__label decision-block__label--benefit">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>
          Expected Benefit
        </div>
        <div class="decision-block__text">${r.benefit}</div>
      </div>
    </div>

    <!-- Affected shipments detail -->
    ${r.affectedShipments.length > 0 ? `
    <div style="margin-top:var(--sp-5)">
      <div style="font-size:.82rem;font-weight:600;color:var(--text-secondary);margin-bottom:var(--sp-3);text-transform:uppercase;letter-spacing:.05em">Affected Shipments</div>
      <div class="data-table-wrap">
        <table class="data-table">
          <thead><tr><th>ID</th><th>Origin → Dest</th><th>Vehicle</th><th>Priority</th><th>Current Status</th><th>Risk</th><th>Value</th></tr></thead>
          <tbody>
            ${r.affectedShipments.map(s => {
              const priorityColor = { critical:'danger', high:'warn', medium:'info', low:'neutral' };
              const riskColor     = { high:'danger', medium:'warn', low:'ok' };
              return `<tr>
                <td><strong class="t-mono">${s.id}</strong></td>
                <td><span style="font-size:.8rem">${s.origin} → ${s.dest}</span></td>
                <td><span class="t-mono">${s.vehicle}</span></td>
                <td><span class="badge badge--${priorityColor[s.priority]||'neutral'}">${s.priority}</span></td>
                <td>${statusBadge(s.status)}</td>
                <td><span class="badge badge--${riskColor[s.risk]||'neutral'}">${s.risk}</span></td>
                <td>${fmtCurrency(s.value)}</td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>` : ''}

    ${r.bestReplacement ? `
    <div style="margin-top:var(--sp-4);padding:var(--sp-4);background:var(--bg-base);border-radius:var(--radius-md);border:1px solid var(--border-subtle)">
      <div style="font-size:.78rem;font-weight:600;color:var(--text-secondary);margin-bottom:var(--sp-2);text-transform:uppercase;letter-spacing:.05em">Best Replacement Vehicle</div>
      <div style="display:flex;align-items:center;gap:var(--sp-3);flex-wrap:wrap">
        <span style="color:var(--brand-primary)">${VEHICLE_TYPE_ICONS[r.bestReplacement.type] || ''}</span>
        <strong>${r.bestReplacement.id}</strong>
        ${statusBadge(r.bestReplacement.status)}
        <span style="font-size:.82rem;color:var(--text-muted)">${r.bestReplacement.location}</span>
        <span class="badge badge--info">${_capStr(r.bestReplacement.capacityKg)} capacity</span>
        <span class="badge badge--neutral">${r.bestReplacement.load}% load</span>
        <span class="badge badge--neutral">⛽ ${r.bestReplacement.fuelPct}%</span>
      </div>
    </div>` : ''}

    ${r.allocationPlan && r.allocationPlan.length > 0 ? `
    <div style="margin-top:var(--sp-4)">
      <div style="font-size:.78rem;font-weight:600;color:var(--text-secondary);margin-bottom:var(--sp-3);text-transform:uppercase;letter-spacing:.05em">Allocation Plan</div>
      ${r.allocationPlan.slice(0,4).map(p => `
        <div style="display:flex;align-items:center;gap:var(--sp-3);padding:var(--sp-2) 0;border-bottom:1px solid var(--border-subtle);flex-wrap:wrap">
          <span class="t-mono" style="font-size:.8rem;font-weight:700;min-width:80px">${p.vehicle.id}</span>
          <span style="font-size:.8rem;color:var(--text-secondary);flex:1">${p.action}</span>
          <span class="badge badge--info">+${_capStr(p.extraLoad)} available</span>
        </div>`).join('')}
    </div>` : ''}

    <!-- Next-step CTA -->
    <div style="margin-top:var(--sp-6);padding:var(--sp-4) var(--sp-5);background:var(--status-info-bg);border:1px solid rgba(0,67,206,.15);border-radius:var(--radius-md);display:flex;align-items:center;gap:var(--sp-4);flex-wrap:wrap">
      <div style="flex:1;min-width:0">
        <div style="font-size:.82rem;font-weight:700;color:var(--brand-secondary);margin-bottom:3px">Next Step</div>
        <div style="font-size:.8rem;color:var(--status-info);line-height:1.5">
          Review the Decision Assistant for prioritised, rule-based recommendations drawn from this fleet state.
        </div>
      </div>
      <button class="btn btn--primary" onclick="navigateTo('assistant')">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 3H5a2 2 0 00-2 2v4m6-6h10a2 2 0 012 2v4M9 3v18m0 0h10a2 2 0 002-2V9M9 21H5a2 2 0 01-2-2V9m0 0h18"/></svg>
        View Recommendations
      </button>
    </div>
  `;
}

function _bvaRow(label, before, after, delta, unit, higherIsBetter) {
  let deltaHtml = '';
  if (delta !== null && delta !== undefined) {
    const isGood = higherIsBetter ? delta >= 0 : delta <= 0;
    const sign   = delta > 0 ? '+' : '';
    const color  = isGood ? 'var(--status-ok)' : 'var(--status-danger)';
    const arrow  = delta > 0 ? '▲' : delta < 0 ? '▼' : '—';
    deltaHtml = delta !== 0
      ? `<span style="color:${color};font-weight:700;font-size:.82rem">${arrow} ${sign}${delta}${unit}</span>`
      : `<span style="color:var(--text-muted);font-size:.82rem">— No change</span>`;
  }
  return `<tr><td>${label}</td><td>${before}</td><td><strong>${after}</strong></td><td>${deltaHtml}</td></tr>`;
}

function resetSimulator() {
  AppState.set('simulator', {
    disruptionType: 'breakdown',
    severity: 'high',
    durationHrs: 24,
    targetVehicle: '',
    result: null,
  });
  renderSimulator();
}

function updateSimParam(key, value) {
  const sim = AppState.get('simulator');
  sim[key]  = value;
  AppState.set('simulator', sim);
  // Re-render the form if breakdown is selected (shows vehicle picker)
  if (key === 'disruptionType') renderSimulator();
}
