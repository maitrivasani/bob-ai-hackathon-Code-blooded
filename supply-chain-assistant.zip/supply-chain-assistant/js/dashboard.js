/**
 * dashboard.js — Main Dashboard view
 * Renders KPI cards, live disruption alert strip, map placeholder,
 * and the top affected shipments panel.
 */

/* ── Helpers ──────────────────────────────────────────────── */
function statusBadge(status) {
  const map = {
    'on-time':    ['ok',      'On Time'],
    'delayed':    ['danger',  'Delayed'],
    'at-risk':    ['warn',    'At Risk'],
    'pending':    ['neutral', 'Pending'],
    'on-route':   ['info',    'En Route'],
    'available':  ['info',    'Available'],
    'maintenance':['warn',    'Maintenance'],
  };
  const [cls, label] = map[status] || ['neutral', status];
  return `<span class="badge badge--${cls}">${label}</span>`;
}

function severityBadge(sev) {
  return `<span class="badge badge--${sev}">${sev.charAt(0).toUpperCase() + sev.slice(1)}</span>`;
}

function fmtCurrency(n) {
  if (n >= 1000000) return '$' + (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000)    return '$' + (n / 1000).toFixed(0) + 'K';
  return '$' + n;
}

function fmtDelay(min) {
  if (!min) return '—';
  if (min < 60) return `+${min} min`;
  return `+${(min / 60).toFixed(1)} hrs`;
}

/* ── KPI computation ──────────────────────────────────────── */
function computeKPIs() {
  const total       = VEHICLES.length;
  const active      = VEHICLES.filter(v => v.status === 'on-route').length;
  const available   = VEHICLES.filter(v => v.status === 'available').length;
  const delayed     = VEHICLES.filter(v => v.status === 'delayed').length;
  const maintenance = VEHICLES.filter(v => v.status === 'maintenance').length;
  const avgUtil     = Math.round(VEHICLES.reduce((s,v) => s + v.utilization, 0) / total);
  const openDisrupt = DISRUPTIONS.filter(d => d.active).length;
  const criticalD   = DISRUPTIONS.filter(d => d.active && d.severity === 'critical').length;
  const revenueRisk = DISRUPTIONS.filter(d => d.active).reduce((s,d) => s + d.impact.revenueAtRisk, 0);
  const shipmentsAffected = DISRUPTIONS.filter(d => d.active).reduce((s,d) => s + d.impact.shipments, 0);
  const atRisk      = SHIPMENTS.filter(s => s.risk === 'high' || s.status === 'at-risk').length;
  const onTime      = SHIPMENTS.filter(s => s.status === 'on-time').length;
  const onTimePct   = Math.round((onTime / SHIPMENTS.length) * 100);

  return { total, active, available, delayed, maintenance, avgUtil, openDisrupt, criticalD, revenueRisk, shipmentsAffected, atRisk, onTimePct };
}

/* ── Spark bar HTML ───────────────────────────────────────── */
function sparkBars(history, colorClass) {
  const max = Math.max(...history, 1);
  const bars = history.map(v => {
    const h = Math.round((v / max) * 100);
    return `<div class="spark-bars__bar" style="height:${h}%"></div>`;
  }).join('');
  return `<div class="spark-bars spark-bars--${colorClass}">${bars}</div>`;
}

/* ── SVG icon helper ──────────────────────────────────────── */
function svgIcon(path, size = 18, color = 'currentColor') {
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${path}"/></svg>`;
}

/* ── Dashboard render ─────────────────────────────────────── */
function renderDashboard() {
  const kpis = computeKPIs();
  const activeDisruptions = DISRUPTIONS.filter(d => d.active)
    .sort((a,b) => ['critical','high','medium','low'].indexOf(a.severity) - ['critical','high','medium','low'].indexOf(b.severity));

  const view = document.getElementById('view-dashboard');

  view.innerHTML = `
    <!-- Hero intro strip -->
    <div class="dashboard-hero">
      <div class="dashboard-hero__left">
        <div class="dashboard-hero__label">Supply Chain Decision-Support System</div>
        <div class="dashboard-hero__title">LogiSense Operations Centre</div>
        <div class="dashboard-hero__sub">
          Monitoring <strong>${VEHICLES.length}</strong> vehicles across
          <strong>${INDIA_ROUTES.length}</strong> routes &bull;
          <strong>${SHIPMENTS.length}</strong> active shipments &bull;
          <strong>${DISRUPTIONS.filter(d=>d.active).length}</strong> open disruptions
        </div>
      </div>
      <div class="dashboard-hero__right">
        <div class="dashboard-hero__stat">
          <div class="dashboard-hero__stat-value" style="color:${kpis.onTimePct>=85?'var(--status-ok)':kpis.onTimePct>=70?'var(--status-warn)':'var(--status-danger)'}">${kpis.onTimePct}%</div>
          <div class="dashboard-hero__stat-label">On-Time Delivery</div>
        </div>
        <div class="dashboard-hero__sep"></div>
        <div class="dashboard-hero__stat">
          <div class="dashboard-hero__stat-value" style="color:${kpis.avgUtil>=70?'var(--status-ok)':'var(--status-warn)'}">${kpis.avgUtil}%</div>
          <div class="dashboard-hero__stat-label">Fleet Utilization</div>
        </div>
        <div class="dashboard-hero__sep"></div>
        <div class="dashboard-hero__stat">
          <div class="dashboard-hero__stat-value" style="color:${kpis.criticalD>0?'var(--status-danger)':kpis.openDisrupt>0?'var(--status-warn)':'var(--status-ok)'}">${kpis.openDisrupt}</div>
          <div class="dashboard-hero__stat-label">Active Disruptions</div>
        </div>
      </div>
    </div>

    <!-- Critical alert strip -->
    ${kpis.criticalD > 0 ? `
    <div class="alert alert--critical">
      <div class="alert__icon">${svgIcon('M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z', 18, 'currentColor')}</div>
      <div class="alert__body">
        <div class="alert__title">${kpis.criticalD} Critical Disruption${kpis.criticalD > 1 ? 's' : ''} Active</div>
        ${activeDisruptions.filter(d => d.severity === 'critical').map(d => d.title).join(' &bull; ')}
      </div>
    </div>` : ''}

    <!-- KPI Cards -->
    <div class="kpi-grid kpi-grid--9">
      <div class="kpi-card kpi-card--info">
        <div class="kpi-card__label">Total Vehicles</div>
        <div class="kpi-card__value">${kpis.total}</div>
        <div class="kpi-card__delta kpi-card__delta--neutral">${kpis.maintenance} in maintenance</div>
      </div>
      <div class="kpi-card kpi-card--ok">
        <div class="kpi-card__label">Active Vehicles</div>
        <div class="kpi-card__value">${kpis.active}</div>
        <div class="kpi-card__delta kpi-card__delta--neutral">En route now</div>
      </div>
      <div class="kpi-card kpi-card--info">
        <div class="kpi-card__label">Available Vehicles</div>
        <div class="kpi-card__value">${kpis.available}</div>
        <div class="kpi-card__delta kpi-card__delta--neutral">Ready to dispatch</div>
      </div>
      <div class="kpi-card kpi-card--danger">
        <div class="kpi-card__label">Delayed Vehicles</div>
        <div class="kpi-card__value">${kpis.delayed}</div>
        <div class="kpi-card__delta kpi-card__delta--up">Behind schedule</div>
      </div>
      <div class="kpi-card kpi-card--warn">
        <div class="kpi-card__label">At-Risk Shipments</div>
        <div class="kpi-card__value">${kpis.atRisk}</div>
        <div class="kpi-card__delta kpi-card__delta--up">High risk flagged</div>
      </div>
      <div class="kpi-card kpi-card--ok">
        <div class="kpi-card__label">On-Time Delivery</div>
        <div class="kpi-card__value">${kpis.onTimePct}%</div>
        <div class="kpi-card__delta kpi-card__delta--neutral">${SHIPMENTS.filter(s=>s.status==='on-time').length} of ${SHIPMENTS.length} shipments</div>
      </div>
      <div class="kpi-card kpi-card--ok">
        <div class="kpi-card__label">Fleet Utilization</div>
        <div class="kpi-card__value">${kpis.avgUtil}%</div>
        <div class="kpi-card__delta kpi-card__delta--neutral">Avg across fleet</div>
      </div>
      <div class="kpi-card kpi-card--warn" style="cursor:pointer" onclick="navigateTo('disruptions')" data-tooltip="View disruptions">
        <div class="kpi-card__label">Active Disruptions</div>
        <div class="kpi-card__value">${kpis.openDisrupt}</div>
        <div class="kpi-card__delta kpi-card__delta--up">${kpis.criticalD} critical</div>
      </div>
      <div class="kpi-card kpi-card--danger" style="cursor:pointer" onclick="navigateTo('disruptions')" data-tooltip="View affected shipments">
        <div class="kpi-card__label">Affected Shipments</div>
        <div class="kpi-card__value">${kpis.shipmentsAffected}</div>
        <div class="kpi-card__delta kpi-card__delta--up">${fmtCurrency(kpis.revenueRisk)} at risk</div>
      </div>
    </div>

    <!-- Main dashboard grid -->
    <div class="dashboard-grid">

      <!-- Left column -->
      <div>
        <!-- Fleet Map Placeholder -->
        <div class="card mb-4" style="margin-bottom: var(--sp-5)">
          <div class="card__header">
            <span class="card__title">India Supply-Chain Network</span>
            <span class="badge badge--info">
              <span class="dot dot--ok" style="margin-right:4px"></span>
              ${INDIA_ROUTES.length} routes monitored
            </span>
          </div>
          <div class="map-canvas" style="min-height:390px;padding:0;">
            ${renderMapSVG()}
          </div>
          <div class="card__footer">
            Hover or click a route line or hub marker for live status, delay, utilisation &amp; risk details.
          </div>
        </div>

        <!-- Affected Shipments Table -->
        <div class="card">
          <div class="card__header">
            <span class="card__title">Affected Shipments</span>
            <span class="badge badge--${SHIPMENTS.filter(s=>s.status!=='on-time'&&s.risk==='high').length>0?'danger':'warn'}">${SHIPMENTS.filter(s => s.status !== 'on-time').length} need attention</span>
          </div>
          <div class="data-table-wrap">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Shipment</th>
                  <th>Route</th>
                  <th>Vehicle</th>
                  <th>Cargo</th>
                  <th>ETA</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                ${SHIPMENTS.filter(s => s.status !== 'on-time').map(s => `
                  <tr>
                    <td><strong>${s.id}</strong></td>
                    <td>
                      <div>${s.origin}</div>
                      <div class="td-meta">→ ${s.dest}</div>
                    </td>
                    <td><span class="t-mono">${s.vehicle}</span></td>
                    <td>${s.cargo}</td>
                    <td>${s.eta}</td>
                    <td>${statusBadge(s.status)}</td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>
          <div class="card__footer" style="cursor:pointer;display:flex;justify-content:space-between;align-items:center" onclick="navigateTo('shipments')">
            <span>View all shipments &rarr;</span>
            <button class="btn btn--primary" style="font-size:.75rem;padding:4px 12px" onclick="event.stopPropagation();navigateTo('simulator')">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
              Simulate
            </button>
          </div>
        </div>
      </div>

      <!-- Right column -->
      <div>
        <!-- Active disruptions feed -->
        <div class="card">
          <div class="card__header">
            <span class="card__title">Active Disruptions</span>
            <span class="badge badge--danger">${kpis.openDisrupt} open</span>
          </div>
          <div class="feed">
            ${activeDisruptions.map((d, i) => `
              <div class="feed-item" onclick="navigateTo('disruptions')">
                <div class="feed-item__icon-col">
                  <div class="feed-item__dot dot--${d.severity === 'critical' ? 'danger' : d.severity === 'high' ? 'warn' : 'info'}"></div>
                  ${i < activeDisruptions.length - 1 ? '<div class="feed-item__line"></div>' : ''}
                </div>
                <div class="feed-item__body">
                  <div class="feed-item__title">${d.title}</div>
                  <div class="feed-item__desc">${d.location} &mdash; ${d.impact.shipments} shipments &bull; ETA resolution: ${d.estimatedResolution}</div>
                  <div class="feed-item__meta">
                    ${severityBadge(d.severity)}
                    <span class="badge badge--neutral">${d.type}</span>
                    <span class="feed-item__time">${fmtCurrency(d.impact.revenueAtRisk)} at risk</span>
                  </div>
                </div>
              </div>`).join('')}
          </div>
          <div class="card__footer" style="cursor:pointer" onclick="navigateTo('disruptions')">
            View all disruptions &rarr;
          </div>
        </div>

        <!-- Decision Assistant mini-panel -->
        <div class="card" style="margin-top: var(--sp-5)">
          <div class="card__header">
            <span class="card__title">Decision Assistant</span>
            <span class="badge badge--neutral" style="font-size:.7rem">Rule-Based Prototype</span>
          </div>
          <div class="feed">
            ${renderAssistantMini()}
          </div>
          <div class="card__footer" style="cursor:pointer" onclick="navigateTo('assistant')">
            View full analysis &rarr;
          </div>
        </div>
      </div>

    </div>
  `;
}

/* ── Interactive India Supply-Chain Map ───────────────────── */

// Map instance tracker — cancelled on next render
var _indiaMapFrame = null;
var _indiaMapRO    = null;

function renderMapSVG() {
  const containerId = 'india-scm-map';

  // Cancel any previous animation loop / resize observer
  if (_indiaMapFrame) { cancelAnimationFrame(_indiaMapFrame); _indiaMapFrame = null; }
  if (_indiaMapRO)    { _indiaMapRO.disconnect(); _indiaMapRO = null; }

  // Build route stats for footer strip
  const activeCount    = INDIA_ROUTES.filter(r => r.status === 'active').length;
  const delayedCount   = INDIA_ROUTES.filter(r => r.status === 'delayed').length;
  const atRiskCount    = INDIA_ROUTES.filter(r => r.status === 'at-risk').length;
  const disruptedCount = INDIA_ROUTES.filter(r => r.status === 'disrupted').length;
  const highUtilCount  = INDIA_ROUTES.filter(r => r.status === 'high-util').length;

  // Schedule canvas init after innerHTML settles
  setTimeout(() => initIndiaMap(containerId), 0);

  return `
    <div id="${containerId}" style="position:relative;width:100%;background:#0d1117;overflow:hidden;display:flex;flex-direction:column;">
      <!-- Canvas area — takes up all space above the strip -->
      <div style="position:relative;width:100%;height:360px;flex-shrink:0;">
        <canvas id="${containerId}-canvas" style="display:block;position:absolute;top:0;left:0;width:100%;height:100%;"></canvas>
        <!-- Tooltip -->
        <div id="${containerId}-tip" style="
          display:none;position:absolute;pointer-events:none;z-index:20;
          background:#1c1c1c;border:1px solid rgba(255,255,255,0.15);border-radius:6px;
          padding:10px 13px;min-width:200px;max-width:260px;box-shadow:0 4px 16px rgba(0,0,0,.5);
          font-family:system-ui,sans-serif;
        "></div>
      </div>
      <!-- Route status strip -->
      <div style="width:100%;background:rgba(13,17,23,0.95);border-top:1px solid rgba(255,255,255,0.08);display:flex;align-items:center;flex-wrap:wrap;min-height:30px;flex-shrink:0;">
        <div class="map-stat-chip"><span class="map-stat-dot" style="background:#24a148"></span>${activeCount} Active</div>
        <div class="map-stat-chip"><span class="map-stat-dot" style="background:#da1e28"></span>${delayedCount} Delayed</div>
        <div class="map-stat-chip"><span class="map-stat-dot" style="background:#f1c21b"></span>${atRiskCount} At-Risk</div>
        <div class="map-stat-chip"><span class="map-stat-dot" style="background:#ff832b"></span>${disruptedCount} Disrupted</div>
        <div class="map-stat-chip"><span class="map-stat-dot" style="background:#0f62fe"></span>${highUtilCount} High-Util</div>
        <div style="margin-left:auto;display:flex;align-items:center;gap:6px;padding:0 12px;font-size:.7rem;color:rgba(255,255,255,.3);">
          <span style="width:6px;height:6px;border-radius:50%;background:#24a148;display:inline-block;animation:live-pulse 2s infinite;flex-shrink:0;"></span>
          LIVE · India Region
        </div>
      </div>
    </div>
  `;
}

/* ── Canvas map engine (called after DOM is ready) ─────────── */
function initIndiaMap(cid) {
  const canvas = document.getElementById(cid + '-canvas');
  if (!canvas) return;
  const wrap = canvas.parentElement;   // the inner 360px div

  /* ── projection: equirectangular ── */
  const BOUNDS = { latMin: 4, latMax: 38, lngMin: 62, lngMax: 108 };
  function project(lat, lng, W, H) {
    const pad = 32;
    return {
      x: ((lng - BOUNDS.lngMin) / (BOUNDS.lngMax - BOUNDS.lngMin)) * (W - pad*2) + pad,
      y: ((BOUNDS.latMax - lat) / (BOUNDS.latMax - BOUNDS.latMin)) * (H - pad*2) + pad
    };
  }

  /* ── hub lookup ── */
  const hubMap = {};
  INDIA_HUBS.forEach(h => { hubMap[h.id] = h; });

  const ROUTE_COLORS = { active:'#24a148', delayed:'#da1e28', 'at-risk':'#f1c21b', disrupted:'#ff832b', 'high-util':'#0f62fe' };
  const HUB_COLORS   = { active:'#24a148', delayed:'#da1e28', 'at-risk':'#f1c21b', disrupted:'#ff832b', 'high-util':'#0f62fe' };

  /* ── bezier control point ── */
  function cpFor(p1, p2) {
    const mx = (p1.x+p2.x)/2, my = (p1.y+p2.y)/2;
    const dx = p2.x-p1.x,     dy = p2.y-p1.y;
    const len = Math.sqrt(dx*dx+dy*dy) || 1;
    const arc = Math.min(len*0.25, 55);
    return { x: mx - dy/len*arc, y: my + dx/len*arc };
  }

  /* ── simplified land outlines ── */
  const LAND_SHAPES = [
    { id:'india',    fill:'rgba(255,255,255,0.06)', stroke:'rgba(255,255,255,0.18)', sw:1.2, pts:[
      [8.1,77.6],[8.4,76.9],[9.2,76.5],[10.5,76.0],[11.0,75.8],[11.9,75.3],[12.8,74.9],[14.0,74.4],
      [14.8,74.2],[15.7,73.9],[16.0,73.6],[16.8,73.5],[17.9,73.2],[18.9,72.8],[20.1,72.7],[21.1,72.6],
      [22.0,72.6],[22.8,70.9],[22.7,69.7],[23.5,68.4],[24.0,68.4],[24.5,68.8],[25.7,68.9],
      [26.6,69.3],[27.5,70.0],[28.0,71.0],[28.6,72.3],[29.3,73.1],[30.3,74.1],[31.5,75.4],
      [32.5,76.0],[33.0,77.0],[33.5,78.2],[34.0,79.5],[34.5,78.5],[35.0,77.7],[35.5,76.0],
      [36.0,75.0],[36.5,74.0],[37.0,74.5],[36.5,76.5],[36.8,78.0],[37.0,79.5],[36.5,81.0],
      [35.5,82.0],[34.0,81.0],[32.5,80.5],[30.2,79.2],[29.0,80.1],[28.0,81.5],[27.0,82.7],
      [26.0,84.6],[25.3,86.0],[24.5,87.6],[23.5,88.5],[22.7,88.4],[22.2,88.7],[21.8,89.0],
      [21.5,89.2],[20.5,88.0],[19.8,86.5],[19.0,85.0],[18.5,84.0],[17.5,82.3],[16.5,81.0],
      [15.5,80.0],[14.5,80.2],[13.5,80.3],[12.5,80.2],[10.8,79.9],[9.5,78.5],[8.5,78.0],[8.1,77.6]
    ]},
    { id:'srilanka', fill:'rgba(255,255,255,0.05)', stroke:'rgba(255,255,255,0.14)', sw:1, pts:[
      [9.8,79.9],[9.2,79.6],[8.4,79.8],[7.9,80.5],[7.6,81.2],[7.8,81.8],[8.3,81.7],[9.0,81.2],[9.8,80.5],[10.2,80.0]
    ]},
    { id:'pakistan', fill:'rgba(255,255,255,0.04)', stroke:'rgba(255,255,255,0.1)',  sw:1, pts:[
      [23.7,67.0],[24.8,66.6],[25.5,66.8],[26.5,67.3],[27.5,68.2],[28.0,69.5],[28.5,70.5],[29.5,71.5],
      [30.5,72.0],[31.5,72.5],[32.5,73.0],[33.5,73.5],[34.5,74.0],[35.5,75.0],[36.5,76.0],[37.0,76.5],
      [36.5,75.0],[36.0,74.0],[35.5,73.5],[35.0,72.0],[34.5,71.0],[34.0,70.5],[33.5,69.5],
      [32.5,68.5],[31.5,67.5],[30.0,66.5],[28.5,65.5],[27.0,64.5],[25.5,63.5],[24.5,63.0],[23.5,63.5],[23.0,65.0]
    ]},
    { id:'bangladesh', fill:'rgba(255,255,255,0.04)', stroke:'rgba(255,255,255,0.1)', sw:1, pts:[
      [21.5,89.2],[22.2,88.7],[22.7,88.4],[23.5,88.5],[24.1,88.8],[24.5,89.5],[25.3,89.8],[26.0,89.5],
      [26.5,90.5],[26.0,91.5],[25.5,92.0],[24.5,92.0],[23.5,91.5],[22.5,91.0],[21.5,91.5],[21.0,90.5]
    ]},
    { id:'nepal',    fill:'rgba(255,255,255,0.04)', stroke:'rgba(255,255,255,0.1)',  sw:1, pts:[
      [28.0,81.5],[28.5,80.5],[29.0,80.1],[29.5,81.0],[30.0,81.5],[30.5,82.0],[31.0,83.5],
      [28.2,84.2],[27.5,84.5],[27.0,84.0],[27.0,82.7]
    ]},
    { id:'myanmar',  fill:'rgba(255,255,255,0.04)', stroke:'rgba(255,255,255,0.1)',  sw:1, pts:[
      [20.5,92.5],[21.0,92.0],[21.8,92.0],[22.5,92.5],[23.5,93.0],[24.5,94.0],[25.5,95.0],[26.0,96.0],
      [25.5,97.5],[24.5,98.0],[23.5,98.5],[22.5,99.0],[21.5,99.5],[20.5,99.0],[20.0,97.5],
      [17.0,97.0],[16.0,98.0],[15.0,98.5],[14.5,97.5],[15.0,96.5],[16.5,95.0],[17.5,94.0],[18.5,93.5],[19.5,93.0]
    ]},
    { id:'bhutan',   fill:'rgba(255,255,255,0.04)', stroke:'rgba(255,255,255,0.1)',  sw:1, pts:[
      [27.0,89.0],[27.5,88.5],[28.0,88.5],[28.5,89.5],[28.5,91.5],[27.5,91.5],[27.0,90.5]
    ]},
    { id:'china-sw', fill:'rgba(255,255,255,0.03)', stroke:'rgba(255,255,255,0.09)', sw:1, pts:[
      [23.0,97.5],[24.0,97.0],[25.0,97.5],[25.0,98.5],[26.0,99.0],[26.5,100.5],[27.0,101.5],[27.5,103.0],
      [26.0,105.0],[24.0,106.0],[22.5,104.0],[21.5,102.0],[22.0,100.5],[22.5,99.0]
    ]},
  ];

  /* ── state ── */
  const dashOffsets = {};
  INDIA_ROUTES.forEach(r => { dashOffsets[r.id] = 0; });
  let W, H, ctx;
  let hoveredRoute = null, hoveredHub = null, lastTime = 0;

  function setupCanvas() {
    W = wrap.offsetWidth  || 700;
    H = wrap.offsetHeight || 360;
    canvas.width  = W * devicePixelRatio;
    canvas.height = H * devicePixelRatio;
    canvas.style.width  = W + 'px';
    canvas.style.height = H + 'px';
    ctx = canvas.getContext('2d');
    ctx.scale(devicePixelRatio, devicePixelRatio);
  }

  function roundRect(cx, x, y, w, h, r) {
    cx.beginPath();
    cx.moveTo(x+r, y); cx.lineTo(x+w-r, y); cx.quadraticCurveTo(x+w,y,x+w,y+r);
    cx.lineTo(x+w,y+h-r); cx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
    cx.lineTo(x+r,y+h);   cx.quadraticCurveTo(x,y+h,x,y+h-r);
    cx.lineTo(x,y+r);     cx.quadraticCurveTo(x,y,x+r,y);
    cx.closePath();
  }

  function draw(ts) {
    _indiaMapFrame = requestAnimationFrame(draw);
    const dt = ts - lastTime; lastTime = ts;

    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#0d1117';
    ctx.fillRect(0, 0, W, H);

    // Grid
    ctx.strokeStyle = 'rgba(255,255,255,0.028)'; ctx.lineWidth = 1;
    for (let i=0;i<8;i++){const gx=20+i*(W-40)/7;ctx.beginPath();ctx.moveTo(gx,0);ctx.lineTo(gx,H);ctx.stroke();}
    for (let j=0;j<6;j++){const gy=20+j*(H-40)/5;ctx.beginPath();ctx.moveTo(0,gy);ctx.lineTo(W,gy);ctx.stroke();}

    // Land
    LAND_SHAPES.forEach(s => {
      if (!s.pts.length) return;
      ctx.beginPath();
      const fp = project(s.pts[0][0],s.pts[0][1],W,H);
      ctx.moveTo(fp.x,fp.y);
      for (let i=1;i<s.pts.length;i++){const p=project(s.pts[i][0],s.pts[i][1],W,H);ctx.lineTo(p.x,p.y);}
      ctx.closePath();
      ctx.fillStyle=s.fill; ctx.fill();
      ctx.strokeStyle=s.stroke; ctx.lineWidth=s.sw; ctx.stroke();
    });

    // Advance dash offsets
    INDIA_ROUTES.forEach(r => {
      const spd = r.status==='disrupted'?0.04:r.status==='delayed'?0.08:0.15;
      dashOffsets[r.id] = (dashOffsets[r.id] + spd*(dt/16.67)) % 24;
    });

    // Routes
    INDIA_ROUTES.forEach(r => {
      const hF=hubMap[r.from],hT=hubMap[r.to]; if(!hF||!hT) return;
      const p1=project(hF.lat,hF.lng,W,H), p2=project(hT.lat,hT.lng,W,H), cp=cpFor(p1,p2);
      const col=ROUTE_COLORS[r.status]||'#8d8d8d';
      const isHov=(hoveredRoute===r.id);
      const lw = isHov?3.5:(r.status==='high-util'?2.5:1.8);
      const alpha = isHov?1.0:(r.status==='disrupted'?0.45:0.7);

      ctx.save();
      ctx.globalAlpha=alpha; ctx.strokeStyle=col; ctx.lineWidth=lw;
      if(r.status==='disrupted'){ctx.setLineDash([6,6]);ctx.lineDashOffset=-dashOffsets[r.id];}
      else if(r.status==='delayed'){ctx.setLineDash([10,4]);ctx.lineDashOffset=-dashOffsets[r.id];}
      else if(r.status==='at-risk'){ctx.setLineDash([14,5]);ctx.lineDashOffset=-dashOffsets[r.id];}
      else{ctx.setLineDash([]);}
      ctx.beginPath();ctx.moveTo(p1.x,p1.y);ctx.quadraticCurveTo(cp.x,cp.y,p2.x,p2.y);ctx.stroke();
      ctx.restore();

      // Direction arrow
      const t=0.68;
      const ax=(1-t)*(1-t)*p1.x+2*(1-t)*t*cp.x+t*t*p2.x;
      const ay=(1-t)*(1-t)*p1.y+2*(1-t)*t*cp.y+t*t*p2.y;
      const atx=2*(1-t)*(cp.x-p1.x)+2*t*(p2.x-cp.x);
      const aty=2*(1-t)*(cp.y-p1.y)+2*t*(p2.y-cp.y);
      ctx.save();
      ctx.globalAlpha=alpha*0.8; ctx.fillStyle=col;
      ctx.translate(ax,ay); ctx.rotate(Math.atan2(aty,atx));
      ctx.beginPath();ctx.moveTo(5,0);ctx.lineTo(-5,-3);ctx.lineTo(-5,3);ctx.closePath();ctx.fill();
      ctx.restore();
    });

    // Hubs
    INDIA_HUBS.forEach(hub => {
      const p=project(hub.lat,hub.lng,W,H);
      const col=HUB_COLORS[hub.status]||'#6f6f6f';
      const isHov=(hoveredHub===hub.id);
      const r=isHov?9:6;
      if(hub.status==='delayed'||hub.status==='at-risk'){
        const pulse=(Math.sin(ts/500)+1)/2;
        ctx.save();ctx.globalAlpha=pulse*0.3;ctx.beginPath();
        ctx.arc(p.x,p.y,r+8+pulse*6,0,Math.PI*2);ctx.fillStyle=col;ctx.fill();ctx.restore();
      }
      if(isHov){
        ctx.save();ctx.globalAlpha=0.22;ctx.beginPath();
        ctx.arc(p.x,p.y,r+5,0,Math.PI*2);ctx.fillStyle=col;ctx.fill();ctx.restore();
      }
      ctx.beginPath();ctx.arc(p.x,p.y,r,0,Math.PI*2);
      ctx.fillStyle=col;ctx.fill();
      ctx.strokeStyle='#0d1117';ctx.lineWidth=1.5;ctx.stroke();
      ctx.beginPath();ctx.arc(p.x,p.y,r*0.4,0,Math.PI*2);
      ctx.fillStyle='rgba(13,17,23,0.75)';ctx.fill();

      const major=['MUM','DEL','CHE','KOL','MUN','JNP','BLR','COL'];
      if(isHov||major.includes(hub.id)){
        ctx.font='bold '+(isHov?'11px':'9px')+' system-ui,sans-serif';
        ctx.fillStyle=isHov?'#ffffff':'rgba(255,255,255,0.65)';
        ctx.textAlign='center';
        const labelY=p.y<H*0.55?p.y+r+11:p.y-r-5;
        ctx.fillText(hub.name,p.x,labelY);
      }
    });

    // Legend
    const lx=W-150,ly=14;
    ctx.save();ctx.globalAlpha=0.92;
    ctx.fillStyle='rgba(13,17,23,0.88)';
    roundRect(ctx,lx,ly,138,118,5);ctx.fill();
    ctx.strokeStyle='rgba(255,255,255,0.1)';ctx.lineWidth=1;
    roundRect(ctx,lx,ly,138,118,5);ctx.stroke();
    [
      {col:'#24a148',label:'Active',    dash:[]},
      {col:'#da1e28',label:'Delayed',   dash:[10,4]},
      {col:'#f1c21b',label:'At-Risk',   dash:[14,5]},
      {col:'#ff832b',label:'Disrupted', dash:[6,6]},
      {col:'#0f62fe',label:'High-Util', dash:[],thick:true},
    ].forEach((li,i) => {
      const iy=ly+14+i*20;
      ctx.strokeStyle=li.col;ctx.lineWidth=li.thick?2.5:1.8;
      ctx.setLineDash(li.dash);ctx.globalAlpha=0.9;
      ctx.beginPath();ctx.moveTo(lx+10,iy);ctx.lineTo(lx+30,iy);ctx.stroke();
      ctx.setLineDash([]);ctx.fillStyle='rgba(255,255,255,0.76)';
      ctx.textAlign='left';ctx.font='9px system-ui,sans-serif';
      ctx.fillText(li.label,lx+36,iy+4);
    });
    ctx.restore();

    // Live dot
    const lp=(Math.sin(ts/800)+1)/2;
    ctx.save();ctx.globalAlpha=0.4+lp*0.5;
    ctx.beginPath();ctx.arc(18,18,4,0,Math.PI*2);ctx.fillStyle='#24a148';ctx.fill();ctx.restore();
    ctx.font='9px system-ui,sans-serif';ctx.fillStyle='rgba(255,255,255,0.32)';
    ctx.textAlign='left';ctx.fillText('LIVE TELEMETRY',28,22);
  }

  /* ── hit testing ── */
  function canvasPos(e){const r=canvas.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top};}

  function hitHub(mx,my){
    for(const hub of INDIA_HUBS){
      const p=project(hub.lat,hub.lng,W,H);
      if((mx-p.x)**2+(my-p.y)**2<144) return hub;
    }
    return null;
  }

  function hitRoute(mx,my){
    for(const r of INDIA_ROUTES){
      const hF=hubMap[r.from],hT=hubMap[r.to]; if(!hF||!hT) continue;
      const p1=project(hF.lat,hF.lng,W,H),p2=project(hT.lat,hT.lng,W,H),cp=cpFor(p1,p2);
      for(let t=0;t<=1;t+=0.05){
        const bx=(1-t)**2*p1.x+2*(1-t)*t*cp.x+t**2*p2.x;
        const by=(1-t)**2*p1.y+2*(1-t)*t*cp.y+t**2*p2.y;
        if((mx-bx)**2+(my-by)**2<64) return r;
      }
    }
    return null;
  }

  function showTip(html,cx,cy){
    const tip=document.getElementById(cid+'-tip'); if(!tip) return;
    const wr=wrap.getBoundingClientRect();
    let tx=cx-wr.left+14, ty=cy-wr.top-12;
    if(tx+270>W) tx=tx-288;
    if(ty<0) ty=8;
    tip.style.left=tx+'px'; tip.style.top=ty+'px';
    tip.innerHTML=html; tip.style.display='block';
  }
  function hideTip(){const t=document.getElementById(cid+'-tip');if(t)t.style.display='none';}

  function hubTip(hub){
    const typeL={port:'Port',rail:'Rail Hub',road:'Road Hub',air:'Air Hub'};
    const stL={active:'Active',delayed:'Delayed','at-risk':'At Risk','high-util':'High Util',disrupted:'Disrupted'};
    const stC={active:'#24a148',delayed:'#da1e28','at-risk':'#f1c21b','high-util':'#0f62fe',disrupted:'#ff832b'};
    const sc=stC[hub.status]||'#8d8d8d', sl=stL[hub.status]||hub.status;
    const uc=hub.utilization>=90?'#0f62fe':hub.utilization>=70?'#24a148':'#f1c21b';
    return `<div style="font-size:.8rem;font-weight:700;color:#fff;margin-bottom:5px">${hub.name}</div>
<div style="font-size:.72rem;color:rgba(255,255,255,.42);margin-bottom:7px">${typeL[hub.type]||hub.type} &bull; ${hub.desc}</div>
<div style="display:flex;gap:12px;margin-bottom:7px">
  <div><div style="font-size:.63rem;color:rgba(255,255,255,.38);text-transform:uppercase;letter-spacing:.05em">Status</div>
    <div style="font-size:.75rem;font-weight:600;color:${sc}">${sl}</div></div>
  <div><div style="font-size:.63rem;color:rgba(255,255,255,.38);text-transform:uppercase;letter-spacing:.05em">Shipments</div>
    <div style="font-size:.75rem;font-weight:600;color:#fff">${hub.activeShipments} active</div></div>
</div>
<div style="font-size:.63rem;color:rgba(255,255,255,.38);text-transform:uppercase;letter-spacing:.05em;margin-bottom:3px">Fleet Utilisation</div>
<div style="background:rgba(255,255,255,.1);border-radius:3px;height:5px;overflow:hidden">
  <div style="height:100%;width:${hub.utilization}%;background:${uc};border-radius:3px"></div></div>
<div style="font-size:.7rem;color:rgba(255,255,255,.45);margin-top:2px">${hub.utilization}% utilised</div>`;
  }

  function routeTip(route){
    const stL={active:'Active',delayed:'Delayed','at-risk':'At Risk','high-util':'High Util',disrupted:'Disrupted / Suspended'};
    const stC={active:'#24a148',delayed:'#da1e28','at-risk':'#f1c21b','high-util':'#0f62fe',disrupted:'#ff832b'};
    const sc=stC[route.status]||'#8d8d8d', sl=stL[route.status]||route.status;
    const delay=route.delay>0?(route.delay>=60?`+${(route.delay/60).toFixed(1)} hrs`:`+${route.delay} min`):'None';
    const rc=route.risk>=70?'#ff832b':route.risk>=40?'#f1c21b':'#24a148';
    const dc=route.delay>0?'#da1e28':'#24a148';
    return `<div style="font-size:.79rem;font-weight:700;color:#fff;margin-bottom:4px">${route.label}</div>
<div style="font-size:.7rem;color:rgba(255,255,255,.4);margin-bottom:7px">Mode: ${route.mode.toUpperCase()}</div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px 12px;margin-bottom:7px">
  <div><div style="font-size:.62rem;color:rgba(255,255,255,.37);text-transform:uppercase;letter-spacing:.05em">Status</div>
    <div style="font-size:.73rem;font-weight:600;color:${sc}">${sl}</div></div>
  <div><div style="font-size:.62rem;color:rgba(255,255,255,.37);text-transform:uppercase;letter-spacing:.05em">Est. Delay</div>
    <div style="font-size:.73rem;font-weight:600;color:${dc}">${delay}</div></div>
  <div><div style="font-size:.62rem;color:rgba(255,255,255,.37);text-transform:uppercase;letter-spacing:.05em">Utilisation</div>
    <div style="font-size:.73rem;font-weight:600;color:#fff">${route.util}%</div></div>
  <div><div style="font-size:.62rem;color:rgba(255,255,255,.37);text-transform:uppercase;letter-spacing:.05em">Risk</div>
    <div style="font-size:.73rem;font-weight:600;color:${rc}">${route.risk}%</div></div>
</div>
<div style="font-size:.64rem;color:rgba(255,255,255,.38)">Cargo: ${route.cargo}</div>`;
  }

  canvas.addEventListener('mousemove', e => {
    const {x,y}=canvasPos(e);
    const hub=hitHub(x,y);
    if(hub){hoveredHub=hub.id;hoveredRoute=null;canvas.style.cursor='pointer';showTip(hubTip(hub),e.clientX,e.clientY);return;}
    const rt=hitRoute(x,y);
    if(rt){hoveredRoute=rt.id;hoveredHub=null;canvas.style.cursor='pointer';showTip(routeTip(rt),e.clientX,e.clientY);return;}
    hoveredHub=null;hoveredRoute=null;canvas.style.cursor='default';hideTip();
  });
  canvas.addEventListener('mouseleave',()=>{hoveredHub=null;hoveredRoute=null;hideTip();});

  /* ── resize ── */
  _indiaMapRO = new ResizeObserver(() => {
    if(_indiaMapFrame){cancelAnimationFrame(_indiaMapFrame);_indiaMapFrame=null;}
    setupCanvas();
    _indiaMapFrame = requestAnimationFrame(draw);
  });
  _indiaMapRO.observe(wrap);

  setupCanvas();
  _indiaMapFrame = requestAnimationFrame(draw);
}
