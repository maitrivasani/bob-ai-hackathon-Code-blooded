/**
 * shipments.js — Shipments view
 * Full searchable, filterable, sortable table with shipment ID, origin,
 * destination, priority, assigned vehicle, ETA, status and risk level.
 */

/* ── Sort state ───────────────────────────────────────────── */
const _shipSort = { col: 'id', dir: 'asc' };

function renderShipments() {
  const view   = document.getElementById('view-shipments');
  const filter = AppState.get('filters').shipmentStatus || 'all';
  const search = AppState.get('filters').shipmentSearch || '';
  const risk   = AppState.get('filters').shipmentRisk   || 'all';

  const onTime  = SHIPMENTS.filter(s => s.status === 'on-time').length;
  const delayed = SHIPMENTS.filter(s => s.status === 'delayed').length;
  const atRisk  = SHIPMENTS.filter(s => s.risk === 'high').length;
  const pending = SHIPMENTS.filter(s => s.status === 'pending').length;

  view.innerHTML = `
    <div class="page-header">
      <div class="page-header__meta">
        <div class="page-header__title">Shipments</div>
        <div class="page-header__sub">${SHIPMENTS.length} total shipments &bull; last updated ${new Date().toLocaleTimeString()}</div>
      </div>
    </div>

    <!-- Stat strip -->
    <div class="stat-row">
      <div class="stat-row__item">
        <span class="stat-row__label">On Time</span>
        <span class="stat-row__value" style="color:var(--status-ok)">${onTime}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">Delayed</span>
        <span class="stat-row__value" style="color:var(--status-danger)">${delayed}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">At Risk</span>
        <span class="stat-row__value" style="color:var(--sev-high)">${atRisk}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">Pending</span>
        <span class="stat-row__value" style="color:var(--text-muted)">${pending}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">On-Time Rate</span>
        <span class="stat-row__value">${Math.round((onTime/SHIPMENTS.length)*100)}%</span>
      </div>
    </div>

    <!-- Filters bar -->
    <div class="filters-bar">
      <div class="search-wrap">
        <svg class="search-icon" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input class="form-input search-input" type="text" placeholder="Search by ID, origin, destination, cargo…"
          value="${search}" oninput="setShipmentSearch(this.value)" id="shipment-search">
      </div>
      <select class="form-select" style="width:auto" onchange="setShipmentFilter(this.value)">
        <option value="all"      ${filter==='all'?'selected':''}>All Statuses</option>
        <option value="on-time"  ${filter==='on-time'?'selected':''}>On Time</option>
        <option value="delayed"  ${filter==='delayed'?'selected':''}>Delayed</option>
        <option value="at-risk"  ${filter==='at-risk'?'selected':''}>At Risk</option>
        <option value="pending"  ${filter==='pending'?'selected':''}>Pending</option>
      </select>
      <select class="form-select" style="width:auto" onchange="setShipmentRisk(this.value)">
        <option value="all"    ${risk==='all'?'selected':''}>All Risk Levels</option>
        <option value="high"   ${risk==='high'?'selected':''}>High Risk</option>
        <option value="medium" ${risk==='medium'?'selected':''}>Medium Risk</option>
        <option value="low"    ${risk==='low'?'selected':''}>Low Risk</option>
      </select>
    </div>

    <!-- Shipments table -->
    <div class="card">
      <div class="card__header">
        <span class="card__title">Shipment Register</span>
        <span class="badge badge--neutral" id="shipment-count">${_getFilteredShipments(filter, search, risk).length} of ${SHIPMENTS.length} shown</span>
      </div>
      <div class="data-table-wrap">
        <table class="data-table sortable-table" id="shipments-table">
          <thead>
            <tr>
              ${_shipTh('id',       'Shipment ID')}
              ${_shipTh('origin',   'Origin')}
              ${_shipTh('dest',     'Destination')}
              ${_shipTh('priority', 'Priority')}
              ${_shipTh('vehicle',  'Vehicle')}
              ${_shipTh('eta',      'Expected Delivery')}
              ${_shipTh('status',   'Status')}
              ${_shipTh('risk',     'Risk Level')}
              <th>Value</th>
            </tr>
          </thead>
          <tbody id="shipments-tbody">
            ${_renderShipmentRows(filter, search, risk)}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function _shipTh(col, label) {
  const isActive = _shipSort.col === col;
  const arrow    = isActive ? (_shipSort.dir === 'asc' ? ' ↑' : ' ↓') : '';
  return `<th class="sortable-th${isActive ? ' sorted' : ''}" onclick="sortShipments('${col}')">${label}${arrow}</th>`;
}

function _getFilteredShipments(filter, search, risk) {
  let list = [...SHIPMENTS];

  if (filter !== 'all')  list = list.filter(s => s.status === filter);
  if (risk   !== 'all')  list = list.filter(s => s.risk   === risk);
  if (search.trim()) {
    const q = search.trim().toLowerCase();
    list = list.filter(s =>
      s.id.toLowerCase().includes(q)     ||
      s.origin.toLowerCase().includes(q) ||
      s.dest.toLowerCase().includes(q)   ||
      s.cargo.toLowerCase().includes(q)  ||
      s.vehicle.toLowerCase().includes(q)
    );
  }

  list.sort((a, b) => {
    let va = a[_shipSort.col], vb = b[_shipSort.col];
    if (typeof va === 'string') va = va.toLowerCase();
    if (typeof vb === 'string') vb = vb.toLowerCase();
    if (va < vb) return _shipSort.dir === 'asc' ? -1 : 1;
    if (va > vb) return _shipSort.dir === 'asc' ? 1 : -1;
    return 0;
  });

  return list;
}

function _renderShipmentRows(filter, search, risk) {
  const list = _getFilteredShipments(filter, search, risk);
  if (list.length === 0) {
    return `<tr><td colspan="9" style="text-align:center;padding:var(--sp-8);color:var(--text-muted)">No shipments match your filters</td></tr>`;
  }
  return list.map(renderShipmentRow).join('');
}

function renderShipmentRow(s) {
  const priorityColor = { critical: 'danger', high: 'warn', medium: 'info', low: 'neutral' };
  const riskColor     = { high: 'danger', medium: 'warn', low: 'ok' };
  const pcol = priorityColor[s.priority] || 'neutral';
  const rcol = riskColor[s.risk]         || 'neutral';

  return `
    <tr class="shipment-row" id="row-${s.id}" onclick="showShipmentDetail('${s.id}')">
      <td><strong class="t-mono">${s.id}</strong></td>
      <td>
        <div>${s.origin}</div>
      </td>
      <td>
        <div>${s.dest}</div>
      </td>
      <td><span class="badge badge--${pcol}">${s.priority}</span></td>
      <td><span class="t-mono">${s.vehicle}</span></td>
      <td>${s.eta}</td>
      <td>${statusBadge(s.status)}</td>
      <td><span class="badge badge--${rcol} risk-badge">${s.risk}</span></td>
      <td><span style="font-size:.8rem;font-weight:600">${fmtCurrency(s.value)}</span></td>
    </tr>`;
}

function sortShipments(col) {
  if (_shipSort.col === col) {
    _shipSort.dir = _shipSort.dir === 'asc' ? 'desc' : 'asc';
  } else {
    _shipSort.col = col;
    _shipSort.dir = 'asc';
  }
  renderShipments();
}

function setShipmentFilter(value) {
  const filters = AppState.get('filters');
  filters.shipmentStatus = value;
  AppState.set('filters', filters);
  renderShipments();
}

function setShipmentSearch(value) {
  const filters = AppState.get('filters');
  filters.shipmentSearch = value;
  AppState.set('filters', filters);

  // Live re-render just the table body for performance
  const filter  = filters.shipmentStatus || 'all';
  const risk    = filters.shipmentRisk   || 'all';
  const tbody   = document.getElementById('shipments-tbody');
  const counter = document.getElementById('shipment-count');
  if (tbody)   tbody.innerHTML = _renderShipmentRows(filter, value, risk);
  if (counter) counter.textContent = _getFilteredShipments(filter, value, risk).length + ' of ' + SHIPMENTS.length + ' shown';
}

function setShipmentRisk(value) {
  const filters = AppState.get('filters');
  filters.shipmentRisk = value;
  AppState.set('filters', filters);
  renderShipments();
}

function highlightShipment(id) {
  const row = document.getElementById('row-' + id);
  if (!row) return;
  row.scrollIntoView({ behavior: 'smooth', block: 'center' });
  row.classList.add('row-highlight');
  setTimeout(() => row.classList.remove('row-highlight'), 2000);
}

function showShipmentDetail(id) {
  const s = SHIPMENTS.find(x => x.id === id);
  if (!s) return;
  const vehicle = VEHICLES.find(v => v.id === s.vehicle);
  const priorityColor = { critical: 'danger', high: 'warn', medium: 'info', low: 'neutral' };
  const riskColor     = { high: 'danger', medium: 'warn', low: 'ok' };

  showModal(`
    <div style="margin-bottom:var(--sp-4)">
      <div style="font-size:1.1rem;font-weight:700;font-family:monospace">${s.id}</div>
      <div style="font-size:.85rem;color:var(--text-muted);margin-top:2px">${s.origin} → ${s.dest}</div>
    </div>
    <div class="detail-grid">
      <div class="detail-item"><span class="detail-label">Cargo</span><span>${s.cargo}</span></div>
      <div class="detail-item"><span class="detail-label">Priority</span><span class="badge badge--${priorityColor[s.priority]}">${s.priority}</span></div>
      <div class="detail-item"><span class="detail-label">Status</span>${statusBadge(s.status)}</div>
      <div class="detail-item"><span class="detail-label">Risk Level</span><span class="badge badge--${riskColor[s.risk]}">${s.risk}</span></div>
      <div class="detail-item"><span class="detail-label">Assigned Vehicle</span><span class="t-mono">${s.vehicle}</span></div>
      <div class="detail-item"><span class="detail-label">Expected Delivery</span><span>${s.eta}</span></div>
      <div class="detail-item"><span class="detail-label">Shipment Value</span><span style="font-weight:700">${fmtCurrency(s.value)}</span></div>
      <div class="detail-item"><span class="detail-label">Weight</span><span>${(s.weightKg/1000).toFixed(1)} tonnes</span></div>
      ${vehicle ? `
      <div class="detail-item"><span class="detail-label">Vehicle Status</span>${statusBadge(vehicle.status)}</div>
      <div class="detail-item"><span class="detail-label">Vehicle Location</span><span>${vehicle.location}</span></div>
      ` : ''}
    </div>
    ${s.status !== 'on-time' ? `
    <div class="alert alert--warn" style="margin-top:var(--sp-4)">
      <div class="alert__icon" style="color:var(--status-warn)">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
      </div>
      <div class="alert__body">
        <div class="alert__title">This shipment requires attention</div>
        <span style="font-size:.8rem">Check disruption feed for active events affecting this route.</span>
      </div>
    </div>` : ''}
  `, s.id + ' — Shipment Details');
}
