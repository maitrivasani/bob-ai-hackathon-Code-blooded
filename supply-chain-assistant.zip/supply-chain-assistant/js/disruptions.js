/**
 * disruptions.js — Disruption Feed + Recovery Recommendations view
 * Supports: 5 disruption types, severity filter, click-to-expand impact panel,
 * notifications for high-risk events.
 */

const DISRUPTION_TYPE_LABELS = {
  weather:          'Severe Weather',
  'port-congestion':'Port Congestion',
  traffic:          'Road Closure / Heavy Traffic',
  breakdown:        'Vehicle Breakdown',
  warehouse:        'Warehouse Delay',
  fuel:             'Fuel Issue',
};

function renderDisruptions() {
  const view   = document.getElementById('view-disruptions');
  const filter = AppState.get('filters').disruption;

  const severityOrder = ['critical','high','medium','low'];
  const filtered = (filter === 'all' ? DISRUPTIONS : DISRUPTIONS.filter(d => d.severity === filter))
    .filter(d => d.active)
    .sort((a,b) => severityOrder.indexOf(a.severity) - severityOrder.indexOf(b.severity));

  const totalRisk = filtered.reduce((s,d) => s + d.impact.revenueAtRisk, 0);
  const totalShip = filtered.reduce((s,d) => s + d.impact.shipments, 0);

  view.innerHTML = `
    <div class="page-header">
      <div class="page-header__meta">
        <div class="page-header__title">Supply Chain Disruptions</div>
        <div class="page-header__sub">${filtered.length} active events &bull; ${fmtCurrency(totalRisk)} total revenue at risk</div>
      </div>
      <div class="page-header__controls">
        <select class="form-select" style="width:auto" onchange="setDisruptionFilter(this.value)">
          <option value="all"      ${filter==='all'?'selected':''}>All Severities</option>
          <option value="critical" ${filter==='critical'?'selected':''}>Critical</option>
          <option value="high"     ${filter==='high'?'selected':''}>High</option>
          <option value="medium"   ${filter==='medium'?'selected':''}>Medium</option>
          <option value="low"      ${filter==='low'?'selected':''}>Low</option>
        </select>
      </div>
    </div>

    <!-- Summary strip -->
    <div class="stat-row">
      <div class="stat-row__item">
        <span class="stat-row__label">Critical</span>
        <span class="stat-row__value" style="color:var(--sev-critical)">${DISRUPTIONS.filter(d=>d.active&&d.severity==='critical').length}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">High</span>
        <span class="stat-row__value" style="color:var(--sev-high)">${DISRUPTIONS.filter(d=>d.active&&d.severity==='high').length}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">Medium</span>
        <span class="stat-row__value" style="color:#7a5f00">${DISRUPTIONS.filter(d=>d.active&&d.severity==='medium').length}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">Affected Shipments</span>
        <span class="stat-row__value">${totalShip}</span>
      </div>
      <div class="stat-row__sep"></div>
      <div class="stat-row__item">
        <span class="stat-row__label">Revenue at Risk</span>
        <span class="stat-row__value">${fmtCurrency(totalRisk)}</span>
      </div>
    </div>

    <!-- Type legend -->
    <div class="disruption-type-legend">
      ${['weather','traffic','breakdown','warehouse','port-congestion'].map(t => `
        <div class="type-chip type-chip--${t.replace('-','')}">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="${DISRUPTION_TYPE_ICONS[t] || ''}"/></svg>
          ${DISRUPTION_TYPE_LABELS[t]}
        </div>`).join('')}
    </div>

    <div class="dashboard-grid">
      <!-- Left: Disruption cards -->
      <div>
        <div class="card">
          <div class="card__header">
            <span class="card__title">Active Disruption Events</span>
            <span class="badge badge--danger">${filtered.length} events</span>
          </div>
          <div class="disruption-list">
            ${filtered.map(d => renderDisruptionRow(d)).join('')}
          </div>
          ${filtered.length === 0 ? `<div class="empty-state"><div class="empty-state__title">No disruptions at this severity level</div></div>` : ''}
        </div>
      </div>

      <!-- Right: Recovery recommendations -->
      <div>
        <div class="card">
          <div class="card__header">
            <span class="card__title">Recovery Recommendations</span>
            <span class="badge badge--info">Rule-Based</span>
          </div>
          <div class="card__body" style="padding:var(--sp-4)">
            ${RECOVERY_ACTIONS.map(r => renderRecoveryCard(r)).join('')}
          </div>
        </div>
      </div>
    </div>

    <!-- Impact detail panel (hidden by default) -->
    <div class="impact-panel" id="impact-panel" style="display:none"></div>
  `;
}

function renderDisruptionRow(d) {
  const impactBarPct = Math.min(100, Math.round((d.impact.revenueAtRisk / 1500000) * 100));
  const impactColor  = d.severity === 'critical' ? 'danger' : d.severity === 'high' ? 'warn' : 'info';
  const typeLabel    = DISRUPTION_TYPE_LABELS[d.type] || d.type;

  const isExpanded = AppState.get('expandedDisruption') === d.id;
  return `
    <div class="disruption-item">
      <div class="disruption-row" onclick="toggleImpactPanel('${d.id}')">
        <div class="disruption-row__sev-bar disruption-row__sev-bar--${d.severity}"></div>
        <div>
          <div class="disruption-row__title">
            ${d.title}
            &nbsp;${severityBadge(d.severity)}
            <span class="badge badge--neutral">${typeLabel}</span>
          </div>
          <div class="disruption-row__detail">${d.description}</div>
          <div class="disruption-row__tags">
            <span class="badge badge--neutral">${d.location}</span>
            <span class="badge badge--neutral">${d.impact.shipments} shipments affected</span>
            <span class="badge badge--neutral">${d.estimatedResolution} to resolve</span>
            ${d.affectedRoutes.map(r => `<span class="badge badge--neutral">${r}</span>`).join('')}
          </div>
          <div style="margin-top:10px">
            <div style="display:flex;justify-content:space-between;margin-bottom:4px">
              <span style="font-size:.72rem;color:var(--text-muted);font-weight:600;text-transform:uppercase;letter-spacing:.05em">Revenue at Risk</span>
              <span style="font-size:.8rem;font-weight:700">${fmtCurrency(d.impact.revenueAtRisk)}</span>
            </div>
            <div class="progress-bar">
              <div class="progress-bar__fill progress-bar__fill--${impactColor}" style="width:${impactBarPct}%"></div>
            </div>
          </div>
          <div style="margin-top:8px;font-size:.78rem;color:var(--text-muted)">
            Vehicles affected: ${d.affectedVehicles.join(', ')} &bull; Delay: ${d.impact.delayHrs > 0 ? d.impact.delayHrs + ' hrs' : 'TBD'}
          </div>
          <div id="hint-${d.id}" style="margin-top:6px;font-size:.75rem;color:var(--brand-primary);font-weight:600">
            ${isExpanded ? '▴ Collapse impact analysis' : '▾ View full impact analysis'}
          </div>
        </div>
        <div style="text-align:right;min-width:80px;flex-shrink:0">
          <div style="font-size:.7rem;color:var(--text-muted);margin-bottom:4px">Est. resolution</div>
          <div style="font-size:.875rem;font-weight:700">${d.estimatedResolution}</div>
        </div>
      </div>
      <div class="disruption-impact-expand" id="expand-${d.id}" style="${isExpanded ? '' : 'display:none'}">
        ${renderImpactExpand(d)}
      </div>
    </div>`;
}

function renderImpactExpand(d) {
  const rec = RECOVERY_ACTIONS.find(r => r.disruptionId === d.id);
  return `
    <div class="impact-expand-body">
      <div class="impact-expand-grid">
        <div class="impact-stat">
          <div class="impact-stat__label">Shipments Affected</div>
          <div class="impact-stat__value" style="color:var(--sev-high)">${d.impact.shipments}</div>
        </div>
        <div class="impact-stat">
          <div class="impact-stat__label">Revenue at Risk</div>
          <div class="impact-stat__value" style="color:var(--status-danger)">${fmtCurrency(d.impact.revenueAtRisk)}</div>
        </div>
        <div class="impact-stat">
          <div class="impact-stat__label">Delay Impact</div>
          <div class="impact-stat__value">${d.impact.delayHrs} hrs</div>
        </div>
        <div class="impact-stat">
          <div class="impact-stat__label">Vehicles Halted</div>
          <div class="impact-stat__value">${d.affectedVehicles.length}</div>
        </div>
      </div>
      <div style="margin-top:var(--sp-4)">
        <div style="font-size:.78rem;font-weight:600;color:var(--text-secondary);margin-bottom:var(--sp-3)">AFFECTED ROUTES</div>
        ${d.affectedRoutes.map(r => `
          <div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border-subtle);font-size:.82rem">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--status-warn)" stroke-width="2"><path d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/></svg>
            ${r}
          </div>`).join('')}
      </div>
      ${rec ? `
      <div style="margin-top:var(--sp-4);padding:var(--sp-4);background:var(--bg-base);border-radius:var(--radius-md);border:1px solid var(--border-subtle)">
        <div style="font-size:.78rem;font-weight:600;color:var(--text-secondary);margin-bottom:var(--sp-2)">RECOMMENDED ACTION</div>
        <div style="font-size:.875rem;font-weight:600">${rec.title}</div>
        <div style="font-size:.8rem;color:var(--text-secondary);margin-top:4px">${rec.description}</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
          <span class="badge badge--ok">${rec.impact.confidence}% confidence</span>
          <span class="badge badge--info">−${rec.impact.delayReductionMin < 60 ? rec.impact.delayReductionMin + ' min' : (rec.impact.delayReductionMin/60).toFixed(1) + ' hrs'} delay</span>
          <span class="badge badge--neutral">Δ Cost: ${fmtCurrency(rec.impact.costDelta)}</span>
        </div>
      </div>` : ''}
      <div style="display:flex;gap:var(--sp-3);margin-top:var(--sp-4);flex-wrap:wrap">
        <button class="btn btn--primary" onclick="navigateTo('simulator')">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
          Run What-If Scenario
        </button>
        <button class="btn btn--ghost" onclick="navigateTo('assistant')">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 3H5a2 2 0 00-2 2v4m6-6h10a2 2 0 012 2v4M9 3v18m0 0h10a2 2 0 002-2V9M9 21H5a2 2 0 01-2-2V9m0 0h18"/></svg>
          Decision Assistant
        </button>
      </div>
    </div>`;
}

function toggleImpactPanel(id) {
  const prev   = AppState.get('expandedDisruption');
  const isSame = prev === id;

  // Collapse previous
  if (prev) {
    const prevEl   = document.getElementById('expand-' + prev);
    const prevHint = document.getElementById('hint-' + prev);
    if (prevEl)   prevEl.style.display = 'none';
    if (prevHint) prevHint.textContent = '▾ View full impact analysis';
  }

  AppState.set('expandedDisruption', isSame ? null : id);

  if (!isSame) {
    const el   = document.getElementById('expand-' + id);
    const hint = document.getElementById('hint-' + id);
    if (el) {
      el.style.display = 'block';
      el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    if (hint) hint.textContent = '▴ Collapse impact analysis';
  }
}

function renderRecoveryCard(r) {
  return `
    <div class="recovery-card" style="margin-bottom:var(--sp-4)">
      <div style="display:flex;align-items:flex-start;gap:var(--sp-3)">
        <div class="recovery-card__number">${r.priority}</div>
        <div>
          <div class="recovery-card__title">${r.title}</div>
          <div style="font-size:.72rem;color:var(--text-muted);margin-top:2px">Re: ${r.disruptionId}</div>
        </div>
      </div>
      <div class="recovery-card__body">${r.description}</div>
      <div class="recovery-card__impact">
        <span class="badge badge--ok">${r.impact.confidence}% confidence</span>
        <span class="badge badge--info">−${r.impact.delayReductionMin < 60 ? r.impact.delayReductionMin + ' min' : (r.impact.delayReductionMin/60).toFixed(1) + ' hrs'} delay</span>
        <span class="badge badge--neutral">Δ Cost: ${fmtCurrency(r.impact.costDelta)}</span>
        ${r.tags.map(t => `<span class="badge badge--neutral">${t}</span>`).join('')}
      </div>
    </div>`;
}

function setDisruptionFilter(value) {
  const filters = AppState.get('filters');
  filters.disruption = value;
  AppState.set('filters', filters);
  renderDisruptions();
}
